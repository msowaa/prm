﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.ComponentModel;
using System.Diagnostics;
using System.Threading;

namespace StringGenerator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private char characterToSplit = '|';
        private StringGen gen = null;

        //generate new random string and save it to clipboard
        private void generateButton_Click(object sender, RoutedEventArgs e)
        {
            if (gen == null)
            {
                gen = new StringGen(CharStringToUse.Text);
            }
            else
            {
                gen.SetCharList(CharStringToUse.Text);
            }
            var finalString = gen.GenerateString(howLong.Text,
                spaceEveryX.Text, spaceEveryY.Text, (bool)isInsertSpacesOn.IsChecked,
                newLineEveryX.Text, newLineEveryY.Text, (bool)isInsertNewLineOn.IsChecked);

            System.Windows.Clipboard.SetText(finalString);
            if (finalString.Length > 100000)
            {
                finalString = "String is too long to display (whole string is in clipboard)";
            }
            output.Text = finalString;

        }

        //generate counter string
        private void generateCounterString_Click(object sender, RoutedEventArgs e)
        {
            if (gen == null)
            {
                gen = new StringGen(CharStringToUse.Text);
            }
            else
            {
                gen.SetCharList(CharStringToUse.Text);
            }

            var finalString = gen.GenerateCounterString(counterStringSize.Text, counterStringSign.Text);

            System.Windows.Clipboard.SetText(finalString);
            if (finalString.Length > 100000)
            {
                finalString = "String is too long to display (whole string is in clipboard)";
            }
            output.Text = finalString;
        }





        private string[] filePaths;
        public IEnumerable<FileInfo> filesInfo;
        private IEnumerable<string> kimballFromCSV;
        private IEnumerable<string> linesFromCSV;
        private List<string> usedKimball;
        string path = "";
        private void SelectFolder_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog folder = new FolderBrowserDialog();
            folder.ShowDialog();
            path = folder.SelectedPath;
            // DirectoryInfo d = new DirectoryInfo(path);
            //filesInfo = d.GetFiles(".jpg");
            filePaths = Directory.GetFiles(path, "*.jpg");
            output.Text = filePaths.Count() + " images";
        }

        private IEnumerable<string> ReadCSV(string fileName)
        {
            usedKimball = new List<string>();
            //string[] lines = File.ReadAllLines(System.IO.Path.ChangeExtension(fileName, ".csv"));
            var lines = File.ReadLines(System.IO.Path.ChangeExtension(fileName, ".csv"));
            characterToSplit = splitCharacter.Text.First();

            return lines.Select(line =>
            {
                var data = line.Split(characterToSplit);
                return data[0];
            });
        }
        private IEnumerable<string> ReadCSVWholeLine(string fileName)
        {
            usedKimball = new List<string>();
            string[] lines = File.ReadAllLines(System.IO.Path.ChangeExtension(fileName, ".csv"));
            return lines;
        }



        private void LoadCSV_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            file.ShowDialog();
            string path = file.FileName;

            kimballFromCSV = ReadCSV(path);
            kimballFromCSV.First().Remove(0);
            output.Text = kimballFromCSV.Count().ToString() + " rows in csv";
            //output.Text = kimballFromCSV.ElementAt(1);
        }
        private void LoadWholeCSV_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*";
            file.ShowDialog();
            string path = file.FileName;

            linesFromCSV = ReadCSVWholeLine(path);
            linesFromCSV.First().Remove(0);
            output.Text = linesFromCSV.Count().ToString() + " rows in csv";
            //output.Text = kimballFromCSV.ElementAt(1);
        }



        BackgroundWorker bgw = new BackgroundWorker();
        int count = 0;

        bool isKimballRandomBool;
        bool isTitleTextRandomBool;
        string CharStringToUseForThread;
        string wynik;
        string titleTextForThread;
        DateTime startTime;
        TimeSpan elapsedTime;
        TimeSpan timeLeft;
        TimeSpan estimatedTotalTime;
        private void ChangeFilesName_Click(object sender, RoutedEventArgs e)
        {
            startTime = DateTime.Now;
            CharStringToUseForThread = CharStringToUse.Text;
            titleTextForThread = titleText.Text;
            isTitleTextRandomBool = (bool)isTitleTextRandom.IsChecked;
            isKimballRandomBool = (bool)isKimballRandom.IsChecked;
            count = 0;
            output.Text = String.Format("Progress: 0/{0} (0%)", filePaths.Count());
            bgw.DoWork += new DoWorkEventHandler(ChangeNamesFiles);
            bgw.ProgressChanged += new ProgressChangedEventHandler(ProgressChanges);
            bgw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bgw_RunWorkerCompleted);
            bgw.WorkerReportsProgress = true;
            bgw.RunWorkerAsync();
            SelectFolder.IsEnabled = false;
            LoadCSV.IsEnabled = false;
            ChangeFilesName.IsEnabled = false;
        }
        void ProgressChanges(object sender, ProgressChangedEventArgs e)
        {
            this.Dispatcher.Invoke((Action)(() =>
     {
         elapsedTime = DateTime.Now - startTime;
         //estimatedTotalTime = TimeSpan.FromTicks((long)(elapsedTime.Ticks * ((double)(filePaths.Count() / (int)e.UserState))));
         //timeLeft = estimatedTotalTime - elapsedTime;
         //output.Text = String.Format("Progress: {0}/{1} ({2}%) \nTime elapsed: {3}, \nEstimated total time: {4}\nTime left: {5}", e.UserState, filePaths.Count(), e.ProgressPercentage,
         //    elapsedTime.ToString(@"hh\:mm\:ss"), estimatedTotalTime.ToString(@"hh\:mm\:ss"), timeLeft.ToString(@"hh\:mm\:ss"));
         output.Text = String.Format("Progress: {0}/{1} ({2}%) \nTime elapsed: {3}", e.UserState, filePaths.Count(), e.ProgressPercentage,
             elapsedTime.ToString(@"hh\:mm\:ss"));
     }));



        }

        void bgw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //do the code when bgv completes its work
            SelectFolder.IsEnabled = true;
            LoadCSV.IsEnabled = true;
            ChangeFilesName.IsEnabled = true;
            //output.Text = wynik;
        }


        void ChangeNamesFiles(object sender, DoWorkEventArgs e)
        {
            StringGen gen2 = null;
            string result = "";
            int kimballNumber = kimballFromCSV.Count();
            if (isKimballRandomBool)
            {
                Random rng = new Random();

                foreach (string file in filePaths)
                {
                    int i = rng.Next(1, kimballNumber);
                    string s = kimballFromCSV.ElementAt(i);
                    while (usedKimball.Contains(s))
                    {
                        i = rng.Next(1, kimballNumber);
                        s = kimballFromCSV.ElementAt(i);
                    }


                    if (!usedKimball.Contains(s))
                    {
                        count++;
                        usedKimball.Add(s);
                        if (gen2 == null)
                        {
                            gen2 = new StringGen(CharStringToUseForThread);
                        }
                        else
                        {
                            gen2.SetCharList(CharStringToUseForThread);
                        }
                        var finalString = "";
                        if (isTitleTextRandomBool)
                        {
                            finalString = gen2.GenerateString("40",
                            "5", "10", true,
                            "50", "50", false);
                        }
                        else
                        {
                            finalString = titleTextForThread + " " + count;
                        }
                        File.Move(file, path + "\\Kimball-" + s + "-" + finalString + ".jpg");
                        //File.Move(file, path + "\\Kimball-" + s + "-" + "t i t l e 1 2 3" + ".jpg");
                        int percent = (count * 100) / filePaths.Count();
                        bgw.ReportProgress(percent, count);
                        //output.Text = count + " out of " + filePaths.Count();
                        result += s + "\n";
                    }

                }
            }
            else
            {

                int iterator = 0;
                bool isParsed = Int32.TryParse(startFromRowCSV.Text, out iterator);
                if (iterator <= 0)
                {
                    iterator = 1;
                }
                if (!isParsed)
                {
                    output.Text = "Cant parse value";
                }
                else
                {
                    foreach (string file in filePaths)
                    {
                        for (int i = iterator; i < kimballNumber; i++)
                        {
                            string s = kimballFromCSV.ElementAt(i);
                            if (s == "Kimball")
                            {

                            }
                            else if (!usedKimball.Contains(s))
                            {
                                var finalString = "";
                                usedKimball.Add(s);
                                count++;
                                if (isTitleTextRandomBool)
                                {
                                    if (gen2 == null)
                                    {
                                        gen2 = new StringGen(CharStringToUseForThread);
                                    }
                                    else
                                    {
                                        gen2.SetCharList(CharStringToUseForThread);
                                    }
                                    finalString = gen2.GenerateString("40",
                                    "5", "10", true,
                                    "50", "50", false);
                                }
                                else
                                {
                                    finalString = titleTextForThread + " " + count;
                                }
                                File.Move(file, path + "\\Kimball-" + s + "-" + finalString + ".jpg");
                                int percent = (count * 100) / filePaths.Count();
                                bgw.ReportProgress(percent, count);
                                //output.Text = count + " out of " + filePaths.Count();
                                result += s + "\n";
                                break;
                            }
                            iterator = i + 1;
                        }
                    }
                }
            }
            wynik = result;
        }

        private void OpenDirectory_Click(object sender, RoutedEventArgs e)
        {
            if (path != "")
            {
                Process.Start(@path);
            }
        }



    }
}
