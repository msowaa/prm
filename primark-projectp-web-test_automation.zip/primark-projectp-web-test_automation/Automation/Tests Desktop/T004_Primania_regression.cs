﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Reflection;


namespace Automation.TestsDesktop
{
    class T004_Primania_regression : WebdriverBaseClass
    {                
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_AddLook()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg";

            string itemName = Helpers.GetSalt();
            string itemPrice = "10";
            string description = "test desc " + Helpers.GetSalt();

            Helpers.SignIn(driver, email, password, false);
            string lookId = Helpers.AddLookToPrimania(driver, path, itemName, itemPrice, description);
            Context.PrimaniaPage.OpenAddedLook();
            Context.Assertions.PrimaniaAssertions.CheckIfLookNameIs(itemName);
            Context.Assertions.PrimaniaAssertions.CheckIfLookPriceIs(itemPrice);
            Context.Assertions.PrimaniaAssertions.CheckIfLookDescriptionIs(description);
        }

        [Test]
        public void P002_FilterLooks()
        {
            string style = "Casual";

            Helpers.CloseCookiePolicy();
            Context.Header.OpenPrimania();
            Context.PrimaniaPage.OpenFilters();
            Context.PrimaniaPage.ChooseCasualFilter();
            Context.PrimaniaPage.OpenFirstLook();
            Context.Assertions.PrimaniaAssertions.CheckIfLookStyleIs(style);
            Context.PrimaniaPage.CloseLook();
            Context.PrimaniaPage.RemoveFilter();
            Context.PrimaniaPage.SortByPopularity();
            Context.PrimaniaPage.SortByDate();
        }


        [Test]
        public void P003_ReportLook()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string report = "automated test " + Helpers.GetSalt();

            Helpers.SignIn(driver, email, password, false);
            Context.Header.OpenPrimania();
            Context.PrimaniaPage.OpenFirstLook();
            Context.PrimaniaPage.ReportLook(report);
        }

        [Test]
        public void P004_LooksNavigation()
        {
            Context.Header.OpenPrimania();
            Context.PrimaniaPage.OpenFirstLook();
            string url1 = driverExt.GetUrl();
            Context.PrimaniaPage.NextLook();
            string url2 = driverExt.GetUrl();
            Context.Assertions.StringsAreNotEqual(url1, url2);
            Context.PrimaniaPage.PreviousLook();
            url2 = driverExt.GetUrl();
            Context.Assertions.StringsAreEqual(url1, url2);
            Context.PrimaniaPage.CloseLook();
            Context.Assertions.PrimaniaAssertions.LookWasClosed();
        }

        [Test]
        public void P005_GivePrimarks()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.OpenPrimania();
            Context.PrimaniaPage.OpenFirstLook();
            Context.PrimaniaPage.FindLookWithoutPrimarks();
            Context.PrimaniaPage.GivePrimarks();
            Context.Assertions.PrimaniaAssertions.PrimarksWereGiven();
            Context.PrimaniaPage.RemovePrimarks();
            Context.Assertions.PrimaniaAssertions.PrimarksWereRemoved();

        }
    }
}