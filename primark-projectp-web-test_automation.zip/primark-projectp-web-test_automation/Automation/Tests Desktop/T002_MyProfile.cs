﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;


namespace Automation.TestsDesktop
{
    class T002_MyProfile : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_MyLooksInProfile()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg";

            string itemName = Helpers.GetSalt();
            string itemPrice = "10";
            string description = "test desc " + Helpers.GetSalt();

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewLooksTab();
            int numberOfMyLooks = Context.ProfilePage.GetMyLooksCount();
            string newlookId = Helpers.AddLookToPrimaniaViaMyProfile(path, itemName, itemPrice, description);

            Context.Header.ViewProfile();
            Context.ProfilePage.ViewLooksTab();
            Context.Assertions.ProfileAssertions.LooksCountIncreasedByOneComparedTo(numberOfMyLooks);
            Context.ProfilePage.OpenFirstLook();
            Context.Assertions.PrimaniaAssertions.LookIdIs(newlookId);
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewLooksTab();
            numberOfMyLooks = Context.ProfilePage.GetMyLooksCount();
            Context.ProfilePage.RemoveLook();
            Context.ProfilePage.WaitUntilLooksCounterUpdates();
            //Context.Assertions.ProfileAssertions.LooksCountDecreasedByOneComparedTo(numberOfMyLooks);
        }

        [Test]
        public void P002_MyPrimarkedLooksInProfile()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewLooksTab();
            int PrimarkedLooksCount = Context.ProfilePage.GetPrimarkedLooksCount();
            Context.Header.OpenPrimania();
            Context.PrimaniaPage.OpenFirstLook();
            Context.PrimaniaPage.FindLookWithoutPrimarks();
            Context.PrimaniaPage.GivePrimarks();
            Context.PrimaniaPage.CloseLook();
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewLooksTab();
            Context.Assertions.ProfileAssertions.PrimarkedLooksCountIncreasedByOneComparedTo(PrimarkedLooksCount);
        }

        [Test]
        public void P003_LooksFromMyStore()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg";

            Helpers.SignIn(driver, email, password, false);
            string lookID = Helpers.AddLookToPrimania(driver, path, "name", "5", "desc");
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewLooksTab();
            Context.ProfilePage.ViewLooksFromMyStore();
            string userStore = Context.ProfilePage.GetUserStore();
            Context.ProfilePage.OpenFirstLookFromMyStore();
            Context.Assertions.PrimaniaAssertions.CheckIfLookStoreIs(userStore);
        }

        [Test]
        public void P004_EditProfileDetails()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;

            string name = "name" + Helpers.GetSalt();
            string surname = "surname" + Helpers.GetSalt();
            string bio = "bio " + Helpers.GetSalt();
            string phone = Helpers.GetSaltWithout_Char();
            string blogUrl = "http://www." + Helpers.GetSalt() + ".com";

            
            Helpers.SignIn(driver, email, password, false);
            Context.Header.EditProfile();            
            Context.ProfilePage.ChangeUserNameTo(name);
            Context.ProfilePage.ChangeUserSurnameTo(surname);
            Context.ProfilePage.ChangeUserBioTo(bio);
            Context.ProfilePage.ChangeUserPhoneNumberTo(phone);
            Context.ProfilePage.ChangeUserBlogUrlTo(blogUrl);
            Context.ProfilePage.ChangeUserCountry();

            Context.ProfilePage.SaveSettings();

            Context.Assertions.ProfileAssertions.UserNameIs(name);
            Context.Assertions.ProfileAssertions.UserBioIs(bio);
            Context.Assertions.ProfileAssertions.UserBlogUrlIs(blogUrl);

            Context.ProfilePage.OpenUserBlog();
        }

        [Test]
        public void P005_UploadUserPhoto()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\avatar.png";

            Helpers.SignIn(driver, email, password, false);

            Context.Header.EditProfile();
            Context.ProfilePage.ChangePhoto(path);
            Context.ProfilePage.SaveSettings();

        }

        [Test]
        public void P006_ChangeMyStore()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.EditProfile();
            string currentStore = Context.ProfilePage.GetUserStore();
            Helpers.ChangeStoreToRandom(currentStore);
            Context.ProfilePage.SaveSettings();
            string changedStore = Context.ProfilePage.GetUserStore();
            Context.Assertions.StringsAreNotEqual(currentStore, changedStore);
        }

        [Test]
        public void P007_DeleteAccount()
        {
            string email = Helpers.CreateUserNoSitecore();
            string password = "qwerty";

            Helpers.SignIn(driver, email, password, false);
            Context.Header.EditProfile();
            Context.ProfilePage.DeleteProfile();
            Context.ProfilePage.DeleteProfileConfirm();
            Context.Header.SignIn();
            //Context.SignInSignUpPage.ChooseSignIn();
            Context.SignInSignUpPage.FillEmailSignInFieldWith(email);
            Context.SignInSignUpPage.FillPasswordSignInFieldWith(password);
            Context.SignInSignUpPage.ClickSignIn();
            Context.Assertions.SignInSignUpAssertions.UserWasNotSignedIn();
        }

        [Test]
        public void P008_AddRemoveFavourites()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, email, password, false);
            Helpers.ClearFavourites(driver);
            Context.Header.OpenProducts();
            Context.Header.ClickFavouritesButton();
            Context.ProfilePage.StartHuntingForFavourites();
            Context.ProductsPage.FavouriteFirstProduct();
            Context.ProductsPage.ConfirmFirstFavourite();
            Context.Assertions.HeaderAssertions.FavouritesCountEqualsOne();
            Context.Header.ClickFavouritesButton();
            Context.ProfilePage.ClickFirstFavourite();
            Context.ProfilePage.ClickLetsAddMoreProducts();
            Context.Assertions.ProductsPageWasOpened();
            Context.Header.ClickFavouritesButton();
            Context.ProfilePage.RemoveFirstFavouriteClickButton();
            Context.ProfilePage.RemoveFirstFavouriteConfirm();
            Context.Assertions.HeaderAssertions.FavouritesCountEqualsZero();
        }

        [Test]
        public void P009_FavouritesWhenNotSignedIn()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, email, password, false);
            Helpers.ClearFavourites(driver);
            Context.Header.SignOut();
            Context.Header.OpenProducts();
            Context.ProductsPage.FavouriteFirstProduct();
            Context.ProductsPage.ConfirmFirstFavourite();
            Context.Assertions.HeaderAssertions.FavouritesCountEqualsOne();
            Context.Header.ClickFavouritesButton();
            Context.ProfilePage.ClickFirstFavourite();
            Context.Assertions.ProfileAssertions.FavouriteDetailsDisplayed();
            Context.ProfilePage.ClickCookieFavouritesExpirationWarning();
            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewFavouritesTab();
            Context.ProfilePage.ClickFirstFavourite();
            Context.Assertions.ProfileAssertions.FavouriteDetailsDisplayed();
        }

        [Test]
        public void P010_FollowingFollowers()
        {
            string email = Users.PrimarkUser001.Email;
            string emailFollow = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser001.Password;
            string passwordFollow = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            string userId = Context.ProfilePage.GetUserId();
            Helpers.ClearFollowing();
            Context.Header.SignOut();

            Helpers.SignIn(driver, emailFollow, passwordFollow, false);
            string lookID = Helpers.AddLookToPrimaniaViaMyProfile(Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg", "name", "5", "desc");
            Context.Header.ViewProfile();
            Helpers.ClearFollowing();
            string followUserId = Context.ProfilePage.GetUserId();
            Context.ProfilePage.ViewFollowersFollowingTab();
            int numberOfFollowers = Context.ProfilePage.GetFollowersCount();
            Context.Header.SignOut();

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            Context.PrimaniaPage.OpenLookWithId(lookID);
            Context.PrimaniaPage.ClickFollow();
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewFollowersFollowingTab();
            Context.ProfilePage.ViewFollowing();
            int numberOfFollowing = Context.ProfilePage.GetFollowingCount();
            Context.Assertions.ProfileAssertions.FollowingCountEqualsOne();
            Context.ProfilePage.ViewFirstFollowingFollower();
            Context.ProfilePage.ViewFavouritesTab();
            Context.Assertions.ProfileAssertions.UserIdIs(followUserId);
            Context.Header.SignOut();

            Helpers.SignIn(driver, emailFollow, passwordFollow, false);
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewFollowersFollowingTab();
            int numberOfFollowersAfterFollowed = Context.ProfilePage.GetFollowersCount();
            Context.Assertions.ProfileAssertions.NumberOfFollowersIncreasedByOneInComparison(numberOfFollowers, numberOfFollowersAfterFollowed);
            Context.ProfilePage.ClickFollow();
            Context.Assertions.ProfileAssertions.FollowingCountEqualsOne();
            Context.ProfilePage.ViewFollowing();
            Context.ProfilePage.ViewFirstFollowingFollower();
            Context.ProfilePage.ViewFollowersFollowingTab();
            Context.ProfilePage.ViewFollowing();

        }

        [Test]
        public void P011_ChangePassword()
        {
            string email = Users.PasswordChangeUser.Email;
            string password = Users.PasswordChangeUser.Password;
            string newPassword = "asdfgh";

            Helpers.SignIn(driver, email, password, false);
            Context.Header.EditProfile();
            Context.ProfilePage.ChangePassword(password, newPassword);
            Context.ProfilePage.SaveSettings();
            Context.Header.SignOut();

            Helpers.SignIn(driver, email, newPassword, false);      //switch back to old password
            Context.Header.EditProfile();
            Context.ProfilePage.ChangePassword(newPassword, password);
            Context.ProfilePage.SaveSettings();
        }

        [Test]
        public void P012_ConnectDisconnectFB()
        {
            string email = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser002.Password;
            string fblogin = Users.SocialServicesUser001.Email;
            string fbPassword = Users.SocialServicesUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.EditProfile();
            Context.ProfilePage.ToggleConnectFbAccount();
            Helpers.LogInToFB(fblogin, fbPassword);
            Context.Header.SignOut();
            Helpers.SignInViaFbWhenLoggedInToFb();
            Context.Header.EditProfile();
            Context.ProfilePage.ToggleConnectFbAccount();
            Context.ProfilePage.SetPasswordAfterFbDisconnect(password);
            Context.ProfilePage.SaveSettings();
            Context.Header.SignOut();
            Helpers.SignIn(driver, email, password, false);     //verify, that fb was disconnected
            Context.Assertions.SignInSignUpAssertions.UserWasSignedIn();
        }

        [Test]
        public void P013_FollowUserViaProfileButton()
        {
            string email = Users.PrimarkUser002.Email;
            string emailFollow = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser002.Password;
            string passwordFollow = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, emailFollow, passwordFollow, false);
            Context.Header.ViewProfile();
            string userId = Context.ProfilePage.GetUserId();
            Context.Header.SignOut();
            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            Helpers.ClearFollowing();
            Helpers.OpenProfileOfUserWithId(userId);
            Context.ProfilePage.ClickFollowUnfollowButton();
            Context.Assertions.ProfileAssertions.UserIsFollowed();
            Context.ProfilePage.ClickFollowUnfollowButton();
            Context.Assertions.ProfileAssertions.UserIsNotFollowed();
        }
        [Test]
        public void P014_ReportUser()
        {
            string email = Users.PrimarkUser001.Email;
            string emailReport = Helpers.CreateUserNoSitecore();
            string password = Users.PrimarkUser001.Password;
            string passwordReport = Users.NewUser.Password;
            string reportReason = "automated test " + Helpers.GetSalt();

            Helpers.SignIn(driver, emailReport, passwordReport, false);
            Context.Header.ViewProfile();
            string userId = Context.ProfilePage.GetUserId();
            Context.Header.SignOut();
            Helpers.SignIn(driver, email, password, false);
            Helpers.OpenProfileOfUserWithId(userId);
            Context.ProfilePage.ClickReportUser();
            Context.ProfilePage.GiveReasonForUserReport(reportReason);
            Context.ProfilePage.SubmitUserReport();
            Context.Assertions.ProfileAssertions.UserWasReported();
        }
        [Test]
        public void P015_FavouritesVisibility()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            string userId = Context.ProfilePage.GetUserId();
            Context.Header.EditProfile();
            Context.ProfilePage.ToggleFavouritesVisibility();
            Context.ProfilePage.SaveSettings();
            Context.Header.SignOut();
            Helpers.OpenProfileOfUserWithId(userId);
            Context.Assertions.ProfileAssertions.FavouritesAreHidden();
            Helpers.SignIn(driver, email, password, false);
            Context.Header.EditProfile();
            Context.ProfilePage.ToggleFavouritesVisibility();
            Context.ProfilePage.SaveSettings();
            Context.Header.SignOut();
            Helpers.OpenProfileOfUserWithId(userId);
            Context.Assertions.ProfileAssertions.FavouritesAreVisible();
        }

    }
}
