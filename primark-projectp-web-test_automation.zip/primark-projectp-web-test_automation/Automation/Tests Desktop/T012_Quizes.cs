﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Automation.TestsDesktop
{
    class T012_Quizes : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_TakeTest()
        {
            Context.QuizPage.OpenQuizPage("quizpn");
            Context.Assertions.QuizAssertions.SharingIconsDisplayed();
            Context.QuizPage.ChooseQuizPage("quizpage1");
            Context.Assertions.QuizAssertions.NextArrowIsntClickable();
            Context.QuizPage.ChooseImageAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Context.Assertions.QuizAssertions.NextArrowIsntClickable();
            Context.QuizPage.PreviousQuestion();
            Context.Assertions.QuizAssertions.PreviousQuestionArrowNotDisplayed();
            Context.Assertions.QuizAssertions.ImageAnswerSelected(1);
            Context.QuizPage.NextQuestion();
            Context.QuizPage.ChoosePhraseAnswerNumber(1);
            Context.Assertions.QuizAssertions.PhraseAnswerSelected(1);
            Context.QuizPage.NextQuestion();
            Context.Assertions.QuizAssertions.ResultsPageDisplayed();
            Context.Assertions.QuizAssertions.SharingIconsDisplayed();
            Context.QuizPage.ClickResultButton();
        }
        [Test]
        public void P002_ShareQuizOnFB()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Helpers.ShareOnFB(WebdriverBaseClass.driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P003_ShareQuizResultsOnFB()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Context.QuizPage.ChooseQuizPage("quizpage1");
            Context.QuizPage.ChooseImageAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Context.QuizPage.ChoosePhraseAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Helpers.ShareOnFB(WebdriverBaseClass.driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P004_ShareQuizOnTwitter()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Helpers.ShareOnTwitter(WebdriverBaseClass.driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P005_ShareQuizResultsOnTwitter()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Context.QuizPage.ChooseQuizPage("quizpage1");
            Context.QuizPage.ChooseImageAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Context.QuizPage.ChoosePhraseAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Helpers.ShareOnTwitter(WebdriverBaseClass.driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P008_ShareQuizOnTumblr()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Helpers.ShareOnTumblr(WebdriverBaseClass.driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P009_ShareQuizResultsOnTumblr()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Context.QuizPage.ChooseQuizPage("quizpage1");
            Context.QuizPage.ChooseImageAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Context.QuizPage.ChoosePhraseAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Helpers.ShareOnTumblr(WebdriverBaseClass.driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P010_ShareQuizOnGPlus()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Helpers.ShareOnGPlus(Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        [Test]
        public void P011_ShareQuizResultsOnGPlus()
        {
            string description = Helpers.GetSalt();
            Context.QuizPage.OpenQuizPage("quizpn");
            Context.QuizPage.ChooseQuizPage("quizpage1");
            Context.QuizPage.ChooseImageAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Context.QuizPage.ChoosePhraseAnswerNumber(1);
            Context.QuizPage.NextQuestion();
            Helpers.ShareOnGPlus(Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, description);
        }
        
        
    }
}
