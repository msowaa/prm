﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Firefox;
using System.Windows.Forms;
using OpenQA.Selenium.Support.UI;
using System.Reflection;
using System.IO;

namespace Automation.TestsDesktop
{
    class T013_ErrorFinders : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        string[] testedUrls = System.IO.File.ReadAllLines(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\JSandGATestedURIs.txt"));
        
        [Test]
        public void P001_CheckJSErrors()
        {
            bool jsErrorNotPresent;
            bool signedInFlag = false;
            int errorMessageCount = 0;
            

            for (int i = 0; i < testedUrls.Length; i++)
            {                
                signedInFlag = Helpers.ScanURLs(i, signedInFlag, testedUrls);
                                
                jsErrorNotPresent = driverExt.CheckForJSErrors();

                if (jsErrorNotPresent != true)
                {
                    errorMessageCount++;
                    Console.WriteLine(" ");
                    Console.WriteLine("JS ERROR FOUND ON: " + driverExt.GetUrl());
                    Console.WriteLine(" ");
                }                
            }
            Console.WriteLine("websites containing js errors: " + errorMessageCount.ToString());
            if (errorMessageCount > 0)
            {
                Console.WriteLine("js errors were found");                
                Assert.Fail("js errors were found");                
            }
            else
            {
                Console.Write("no js errors were found");
            }
        }

        [Test]
        public void P002_CheckGAData()
        {
            bool signedInFlag = false;
            bool GADataWasSent = false;
            int WebsitesWithNotSentGAData = 0;

            for (int i = 0; i < testedUrls.Length; i++)
            {

                if ((testedUrls[i] != "en/search") && (testedUrls[i] != "en/account/settings22222"))
                {
                    signedInFlag = Helpers.ScanURLs(i, signedInFlag, testedUrls);
                    GADataWasSent = driverExt.CheckIfGAWasSent();
                }
                
                if (GADataWasSent != true)
                {
                    WebsitesWithNotSentGAData++;
                    Console.WriteLine(" ");
                    Console.WriteLine("GA data not sent on: " + driverExt.GetUrl());
                    Console.WriteLine(" ");                    
                }                
            }
            Console.WriteLine("websites with GA data not sent: " + WebsitesWithNotSentGAData.ToString());
            if (WebsitesWithNotSentGAData > 0)
            {
                Console.WriteLine("GA data not sent");
                Assert.Fail("GA data not sent");
            }
            else
            {
                Console.Write("GA data is sent correctly");
            }
        }

        



    }
}
