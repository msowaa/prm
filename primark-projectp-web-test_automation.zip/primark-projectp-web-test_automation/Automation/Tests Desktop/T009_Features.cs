﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Windows.Forms;

namespace Automation.TestsDesktop
{
    [TestFixture]
    class T009_Features : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_TopCarouselNavigation()
        {
            Context.Header.OpenFeatures();
            Context.FeaturesPage.ViewSecondTopCarouselItem();
            Context.FeaturesPage.ViewThirdTopCarouselItem();
            Context.Assertions.FeaturesAssertions.NextArrowNotDisplayed();
            Context.FeaturesPage.ViewFirstTopCarouselItem();
            Context.Assertions.FeaturesAssertions.PreviousArrowNotDisplayed();
            Context.FeaturesPage.ClickNextTopCarouselItem();
            Context.FeaturesPage.ClickPreviousTopCarouselItem();
            Context.FeaturesPage.ViewFirstTopCarouselItem(true);            
        }
        [Test]
        public void P002_OpenFeatureFourRowContainer()
        {
            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P003_OpenFeatureTwoRowContainer()
        {
            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromTwoRowContainer();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P004_OpenFeature3To1Container()
        {
            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFeatureFrom3To1Container();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P005_FilterFeatures()
        {
            string filterFeaturesCategory = "MEN";

            Context.Header.OpenFeatures();
            Context.FeaturesPage.SelectFilter(filterFeaturesCategory);
            Context.FeaturesPage.OpenFirstFeatureFromTwoRowContainer();
            Context.Assertions.FeaturesAssertions.FeatureIsInCategory(filterFeaturesCategory);
        }
        [Test]
        public void P006_FeatureDeeplinkNavigation()
        {
            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();
            Context.FeaturesPage.NextFeature();
            Context.FeaturesPage.PreviousFeature();
        }
        [Test]
        public void P007_FollowUnfollowEditor()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            Helpers.ClearFollowing();
            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();
            Context.FeaturesPage.ClickFollowUnfollowEditorButton();
            Context.Assertions.FeaturesAssertions.EditorIsFollowed();
            Context.FeaturesPage.ClickFollowUnfollowEditorButton();
            Context.Assertions.FeaturesAssertions.EditorIsUnfollowed();
        }
        [Test]
        public void P008_ShareFeatureOnFB()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnFB(driver, email, password, description);
        }
        [Test]
        public void P009_ShareFeatureOnTwitter()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnTwitter(driver, email, password, description);
        }
        [Test]
        public void P010_ShareFeatureOnPinterest()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;

            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnPinterest(driver, email, password);
        }
        [Test]
        public void P011_ShareFeatureOnTumblr()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnTumblr(driver, email, password, description);
        }
        [Test]
        public void P012_ShareFeatureOnGooglePlus()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Context.Header.OpenFeatures();
            Context.FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnGPlus(email, password, description);
        }
        [Test]
        public void P013_LoadMore()
        {
            Context.Header.OpenFeatures();
            Context.FeaturesPage.SelectFilter("Women");
            Context.FeaturesPage.LoadMore();
            Context.Assertions.FeaturesAssertions.MoreWasLoaded();
        }
    
    }
}
