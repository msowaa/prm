﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Firefox;
using System.Windows.Forms;
using OpenQA.Selenium.Support.UI;
using System.Reflection;
using System.IO;

namespace Automation.TestsDesktop
{
    class T015_URIScanners : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_CheckContactUs()
        {
            bool signedInFlag = false;
            string[] contactUsTestedURIs = System.IO.File.ReadAllLines(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\contactUsTestedURIs.txt"));

            System.IO.StreamWriter whoopsFile = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\ContactUs\WhoopsURIs.txt"), false);
            System.IO.StreamWriter faqFile = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\ContactUs\FaqURIs.txt"), false);
            System.IO.StreamWriter contactUsFile = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\ContactUs\ContactUsURIs.txt"), false);
            System.IO.StreamWriter notContactUsNorFaqNorWhoops = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\ContactUs\NotContactUsNorFaqNorWhoops.txt"), false);


            for (int i = 0; i < contactUsTestedURIs.Length; i++)
            {
                signedInFlag = Helpers.ScanURLs(i, signedInFlag, contactUsTestedURIs);

                if (QuickCheckIfElementExists(By.CssSelector(".error-page>.table>.cell>h1")))
                {
                    whoopsFile.WriteLine('"' + contactUsTestedURIs[i] + '"' + ',');
                }
                else if (QuickCheckIfElementExists(By.Id("faq-rich-text-body")))
                {
                    faqFile.WriteLine('"' + contactUsTestedURIs[i] + '"' + ',');
                }
                else if (QuickCheckIfElementExists(By.Id("PhoneNumber")))
                {
                    contactUsFile.WriteLine('"' + contactUsTestedURIs[i] + '"' + ',');
                }
                else
                {
                    notContactUsNorFaqNorWhoops.WriteLine('"' + contactUsTestedURIs[i] + '"' + ',');
                    
                }

            }
            whoopsFile.Close();
            faqFile.Close();
            contactUsFile.Close();
        }
        
        [Test]
        public void P002_CheckSuppliersForm()
        {
            bool signedInFlag = false;
            string[] suppliersTestedURIs = System.IO.File.ReadAllLines(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\suppliersTestedURIs.txt"));

            System.IO.StreamWriter whoopsFileSuppliers = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\Suppliers\WhoopsURIsSuppliers.txt"), false);
            System.IO.StreamWriter suppliersFile = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\Suppliers\SuppliersURIs.txt"), false);
            System.IO.StreamWriter notSuppliersNorWhoops = new System.IO.StreamWriter(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\CUandSFResults\Suppliers\NotSuppliersNorWhoops.txt"), false);

            for (int i = 0; i < suppliersTestedURIs.Length; i++)
            {
                signedInFlag = Helpers.ScanURLs(i, signedInFlag, suppliersTestedURIs);

                if (QuickCheckIfElementExists(By.CssSelector(".error-page>.table>.cell>h1")))
                {
                    whoopsFileSuppliers.WriteLine('"' + suppliersTestedURIs[i] + '"' + ',');
                }
                else if (QuickCheckIfElementExists(By.Id("Name")))
                {
                    suppliersFile.WriteLine('"' + suppliersTestedURIs[i] + '"' + ',');
                }
                else
                {
                    notSuppliersNorWhoops.WriteLine('"' + suppliersTestedURIs[i] + '"' + ',');
                }
            }
            whoopsFileSuppliers.Close();
            suppliersFile.Close();
            notSuppliersNorWhoops.Close();
        }

        [Test]
        public void P003_CheckWNRedirects()
        {
            bool signedInFlag = false;
            int numberOfWrongRedirects = 0;
            string actualURL = "";

            string[] redirectFrom = System.IO.File.ReadAllLines(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\redirectFrom.txt"));
            string[] redirectTo = System.IO.File.ReadAllLines(Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory), @"Resources\redirectTo.txt"));

            if (redirectFrom.Length != redirectTo.Length)
            {
                Assert.Fail("redirect tables have unequal number of rows");
            }
            else
            {
                for (int i = 0; i < redirectFrom.Length; i++)
                {
                    signedInFlag = Helpers.ScanURLs(i, signedInFlag, redirectFrom);
                    actualURL = driverExt.GetUrl();

                    if (!actualURL.Contains(redirectTo[i]))
                    {
                        numberOfWrongRedirects++;
                        Console.WriteLine("wrong redirect on: " + redirectFrom[i]);
                        Console.WriteLine("should redirect to: " + redirectTo[i]);
                        Console.WriteLine("redirects to: " + actualURL);
                        Console.WriteLine(" ");
                    }
                }
                if (numberOfWrongRedirects > 0)
                {
                    Console.WriteLine("number of wrong redirects = " + numberOfWrongRedirects);
                    Assert.Fail("wrong redirects found - number of wrong redirects = " + numberOfWrongRedirects);
                }
            }
        }


        public bool QuickCheckIfElementExists(By by)
        {
            try
            {
                driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(1));
                new WebDriverWait(driver, TimeSpan.FromSeconds(1)).Until(ExpectedConditions.ElementExists(by));
                return true;
            }
            catch
            {
                return false;
            }
        }



    }
}
