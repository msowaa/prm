﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Windows.Forms;

namespace Automation.TestsDesktop
{
    [TestFixture]
    class T007_Search : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_SearchNavigation()
        {
            string searchText = "shoe";

            Context.Header.OpenSearchOverlay();
            Context.Search.CloseSearchOverlay();
            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText);
            Context.Search.SearchButtonClick();
            Context.Search.ViewAllProductsFound();
            Context.Search.ProductSearchResultrFilterLowestPrice();
            Context.Search.ProductSearchResultsFilterHighestPrice();
            Context.Search.ProductSearchResultsFilterLatest();
            Context.Search.BackToSearch();
            Context.Search.ViewFirstFoundFeature();
        }

        [Test]
        public void P002_SearchSuggestions()
        {
            string searchText = "pri";

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText);
            Context.Search.SelectFirstSuggestion();
            Context.Assertions.SearchAssertions.SomethingWasFoundInDetailedResults();
        }

        [Test]
        public void P003_NoSearchResults()
        {
            string searchText = "search" + Helpers.GetSalt();

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Assertions.SearchAssertions.NothingWasFound();
            Context.Search.NoResultsTryAgain();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Assertions.SearchAssertions.NothingWasFound();
            Context.Search.NoResultsBrowseProducts();
            Context.Assertions.ProductsPageWasOpened();
        }
        [Test]
        public void P004_FindAProduct()
        {
            string searchText = "shoe";

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.ViewFirstFoundProductDeeplink();
            Context.Assertions.ProductsAssertions.DeeplinkWasOpended();
            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.ViewAllProductsFound();
            Context.Search.ViewFirstFoundProductDeeplink();
            Context.Assertions.ProductsAssertions.DeeplinkWasOpended();
        }
        [Test]
        public void P005_FindAFeature()
        {
            string searchText = "shoe";

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.ViewFirstFoundFeature();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.ViewAllFeaturesFound();
            Context.Search.ViewFirstFeatureInFearureSearchResults();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P006_FindStores()
        {
            string searchText = "london";

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.ViewStores();
            Context.Assertions.OurStoresPageWasOpened();
        }
        [Test]
        public void P007_FindCareers()
        {
            string searchText = "london";

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.ViewCareers();
            Context.Assertions.CareersPageWasOpened();
        }
        [Test]
        public void P008_SearchHistory()
        {
            string searchText = "shoe";

            Context.Header.OpenSearchOverlay();
            Context.Search.FillSearchFieldWith(searchText, true);
            Context.Search.CloseSearchOverlay();
            Context.Header.OpenSearchOverlay();
            Context.Assertions.SearchAssertions.FirstRecentSearchIs(searchText);
            Context.Search.SelectFirstRecentSearch();
            Context.Assertions.SearchAssertions.SomethingWasFound();
        }

    }
}
