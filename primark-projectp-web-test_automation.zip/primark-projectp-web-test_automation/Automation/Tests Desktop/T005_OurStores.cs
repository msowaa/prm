﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;


namespace Automation.TestsDesktop
{
    [TestFixture]
    class T005_OurStores : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();

        }
        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }
        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }
        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }
        
        //[Test]
        public void P001_OurStoresFeaturedList()
        {
            driver.Navigate().GoToUrl(AppUrl + "en/our-stores/");
            var storeBoxList = driver.FindElement(By.Id("stores")).FindElements(By.CssSelector(".store-box"));
            Console.WriteLine(storeBoxList.Count);
            int i = 0;
            List<string> featuredStoresList = new List<string>();
            foreach (var store in storeBoxList)
            {
                Console.WriteLine(store.GetAttribute("id"));
                if (!store.GetAttribute("class").Contains("store-search-box"))
                {
                    featuredStoresList.Add(store.GetAttribute("id").Substring(6));
                }
                i++;
            }
            Console.WriteLine(featuredStoresList.Count);


            Helpers.LogInToSitecoreAsAdmin(driver);
            driver.FindElement(By.CssSelector(".scEditorTabHeaderNormal>span")).Click();
            IWebElement contentPage = driver.FindElement(By.CssSelector(".scEditorSections"));
            var list = contentPage.FindElements(By.XPath("./div"));
            i = 1;
            foreach (var x in list)
            {
                Console.WriteLine(x.Text);
                if (x.Text.ToLower() == "stores")
                {

                    break;
                }
                i++;
            }
            IWebElement storesTable = contentPage.FindElement(By.XPath(".//table[" + i + "]/tbody/tr/td/table/tbody/tr/td[2]"));
            var selectedFeaturedStores = storesTable.FindElements(By.XPath(".//td[3]/select/option"));
            List<string> selectedStoresText = new List<string>();
            foreach (var x in selectedFeaturedStores)
            {
                string temp = x.Text;
                //Console.WriteLine(temp);
                selectedStoresText.Add(temp);
            }
            i = 0;

            foreach (var store in featuredStoresList)
            {
                StringAssert.Contains(store.ToLower(), selectedStoresText[i].ToLower());
                i++;
            }
            //todo: change featured stores in sitecore, publish and verify it was changed in FE
            //selectedFeaturedStores[0].Click();
            //string removedStore = selectedFeaturedStores[0].Text;
            //storesTable.FindElement(By.XPath(".//td[2]/img[2]")).Click();
        }


        [Test]
        public void P001_OurStoresLocateMyNearestStore()
        {
            Context.Header.OpenOurStores();
            Context.OurStoresPage.ClickLocateNearestStore();
            Context.OurStoresPage.WaitForStoresListLoad();
            Context.Assertions.OurStoresAssertions.NearestStoreDistance();            
        }

        [Test]
        public void P002_OurStoresStoreDetails()
        {
            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.Assertions.OurStoresAssertions.StoreDetailsDisplayed();
        }

        [Test]
        public void P003_OurStoresSetAsMyPrimark()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string storeSearchFirstLetter = Helpers.GenerateRandomLetter();

            Helpers.SignIn(driver, email, password, false);
            Context.Header.ViewProfile();
            string currentStore = Context.ProfilePage.GetUserStore();
            Context.Header.OpenOurStores();
            Context.OurStoresPage.SearchForStore(storeSearchFirstLetter);
            Helpers.OpenStoreDifferentFrom(currentStore);
            Context.OurStoresPage.SetAsMyPrimark();
            string storeName = Context.OurStoresPage.GetStoreName();
            Context.Header.ViewProfile();
            string changedStore = Context.ProfilePage.GetUserStore();
            Context.Assertions.StringsAreNotEqual(currentStore, changedStore);           
        }

        [Test]
        public void P004_StoreProductsDisplayed()
        {
            Context.Footer.CloseCookiesInformation();
            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.OurStoresPage.OpenFirstProductInStore();
            Context.Assertions.ProductsAssertions.DeeplinkWasOpended();
            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.OurStoresPage.ClickViewLatestProductsButton();
            Context.Assertions.ProductsPageWasOpened();
        }

        [Test]
        public void P005_FavouritesInStoreDetails()
        {
            int numberOfFavourites = Context.Header.FavouritesCount();

            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.OurStoresPage.FavouriteAProductInStore();
            Context.Assertions.ProductsAssertions.FirstFavouriteWasAdded();
            Context.Assertions.HeaderAssertions.FavouritesCountEquals(numberOfFavourites + 1);
            Context.Assertions.ProductsAssertions.ProductWasFavourited();
            Context.OurStoresPage.UnfavouriteAProductInStore();
            Context.Assertions.ProductsAssertions.ProductWasUnfavourited();
        }

    }
}
