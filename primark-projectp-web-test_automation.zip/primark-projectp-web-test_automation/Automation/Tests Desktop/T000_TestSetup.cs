﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Firefox;

namespace Automation.TestsDesktop
{
    [TestFixture]
    class T000_TestSetup : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }


        [Test]
        public void AddUsers()
        {
            Helpers.CreateUser(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Helpers.CreateUser(driver, Users.PrimarkUser002.Email, Users.PrimarkUser002.Password);
            Helpers.CreateUser(driver, Users.PasswordChangeUser.Email, Users.PasswordChangeUser.Password);        
        }
        

    }
}
