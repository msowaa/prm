﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Windows.Forms;

namespace Automation.TestsDesktop
{
    [TestFixture]
    class T008_Homepage : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_TopCarouselNavigation()
        {
            Context.Header.OpenHomepage();
            Context.Homepage.ViewSecondTopCarouselItem();
            Context.Homepage.ViewThirdTopCarouselItem();
            Context.Assertions.HomepageAssertions.NextArrowNotDisplayed();
            Context.Homepage.ViewFirstTopCarouselItem();
            Context.Assertions.HomepageAssertions.PreviousArrowNotDisplayed();
            Context.Homepage.ClickNextTopCarouselItem();
            Context.Homepage.ClickPreviousTopCarouselItem();
            Context.Homepage.ViewFirstTopCarouselItem(true);
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P002_OpenProductsCTA()
        {
            Context.Header.OpenHomepage();
            Context.Homepage.OpenFirstCTA2To2();
            Context.Assertions.ProductsPageWasOpened();
        }
        [Test]
        public void P003_OpenSocialLinksFeature()
        {
            Context.Header.OpenHomepage();
            Context.Homepage.OpenSocialLinksFeature();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P004_OpenSocialLinks()
        {
            Context.Header.OpenHomepage();
            Context.Homepage.OpenSocialLinksFB();
            Context.Assertions.HeaderAssertions.SocialLinksFBWasOpened();
            Context.Homepage.OpenSocialLinksTwitter();
            Context.Assertions.HeaderAssertions.SocialLinksTwitterWasOpened();
            Context.Homepage.OpenSocialLinksPinterest();
            Context.Assertions.HeaderAssertions.SocialLinksPinterestWasOpened();
            Context.Homepage.OpenSocialLinksInstagram();
            Context.Assertions.HeaderAssertions.SocialLinksInstagramWasOpened();
            Context.Homepage.OpenSocialLinksGooglePlus();
            Context.Assertions.HeaderAssertions.SocialLinksGooglePlusWasOpened();
        }
        [Test]
        public void P005_OpenFeatureRowFirstFeature()
        {
            Context.Header.OpenHomepage();
            Context.Homepage.OpenFeatureRowFirstFeature();
            Context.Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P006_PrimaniaCarousel()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Context.Header.OpenHomepage();
            Context.Homepage.PrimaniaCarouselClickNextArrow();
            Context.Homepage.PrimaniaCarouselClickPreviousArrow();
            Context.Homepage.PrimaniaCarouselOpenLook();
            Context.Assertions.PrimaniaAssertions.LookWasOpened();
            Context.Header.OpenHomepage();
            Context.Homepage.PrimaniaCarouselUploadLook();
            Context.Assertions.PrimaniaAssertions.LookUploadPageWasOpened();
            Context.Header.OpenHomepage();
            Context.Homepage.PrimaniaCarouselBrowsePrimania();
            Context.Assertions.PrimaniaPageWasOpened();
        }
        [Test]
        public void P007_ProductsCarousel()
        {
            Context.Header.OpenHomepage();
            Context.Homepage.ProductsCarouselClickNextArrow();
            Context.Homepage.ProductsCarouselClickPreviousArrow();
            Context.Homepage.ProductsCarouselFavouriteItem();
            Context.Assertions.ProductsAssertions.FirstFavouriteWasAdded();
            Context.ProductsPage.ConfirmFirstFavourite();
            Context.Homepage.ProductsCarouselOpenProductDetails();
            Context.Assertions.ProductsAssertions.DeeplinkWasOpended();
        }
    }
}
