﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;


namespace Automation.TestsDesktop
{
    [TestFixture]
    class T006_OurEthics : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_browseQA()
        {
            Context.Header.OpenOurEthics();
            string question1 = Context.OurEthicsPage.GetQuestionText();
            Context.OurEthicsPage.NextQuestion();
            string question2 = Context.OurEthicsPage.GetQuestionText();
            Context.Assertions.StringsAreNotEqual(question1, question2);
            Context.OurEthicsPage.PreviousQuestion();
            question2 = Context.OurEthicsPage.GetQuestionText();
            Context.Assertions.StringsAreEqual(question1, question2);
            Context.OurEthicsPage.QuestionFindOut();
            question1 = Context.OurEthicsPage.GetQuestionText();
            Context.OurEthicsPage.NextQuestionDeeplink();
            question2 = Context.OurEthicsPage.GetQuestionText();
            Context.Assertions.StringsAreNotEqual(question1, question2);
            Context.OurEthicsPage.PreviousQuestionDeeplink();
            question2 = Context.OurEthicsPage.GetQuestionText();
            Context.Assertions.StringsAreEqual(question1, question2);
        }

        [Test]
        public void P002_ShareContentOnFBDeeplink()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInDeeplink();
            Helpers.ShareOnFB(driver, email, password, description);

        }

        [Test]
        public void P003_ShareContentOnFBOverlay()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInOverlay();

            Helpers.ShareOnFB(driver, email, password, description);

        }

        [Test]
        public void P004_ShareContentOnTwitterDeeplink()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInDeeplink();
            Helpers.ShareOnTwitter(driver, email, password, description);
        } 

        [Test]
        public void P005_ShareContentOnTwitterOverlay()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInOverlay();
            Helpers.ShareOnTwitter(driver, email, password, description);
        }

        [Test]
        public void P006_ShareContentOnPinterestDeeplink()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInDeeplink();
            Helpers.ShareOnPinterest(driver, email, password);
        }
        [Test]
        public void P007_ShareContentOnPinterestOverlay()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInOverlay();
            Helpers.ShareOnPinterest(driver, email, password);
        }

        [Test]
        public void P008_ShareContentOnTumblrDeeplink()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInDeeplink();
            Helpers.ShareOnTumblr(driver, email, password, description);
        }

        [Test]
        public void P009_ShareContentOnTumblrOverlay()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInOverlay();
            Helpers.ShareOnTumblr(driver, email, password, description);
        }
        [Test]
        public void P010_ShareContentOnGooglePlusDeeplink()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInDeeplink();
            Helpers.ShareOnGPlus(email, password, description);
        }
        [Test]
        public void P011_ShareContentOnGooglePlusOverlay()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.Header.OpenOurEthics();
            Context.OurEthicsPage.OpenExampleArticleInOverlay();
            Helpers.ShareOnGPlus(email, password, description);
        }
    }
}
