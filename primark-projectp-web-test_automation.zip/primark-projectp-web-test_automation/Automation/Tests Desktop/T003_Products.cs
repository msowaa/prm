﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Automation.TestsDesktop
{
    class T003_Products : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_ViewProductDetails()
        {
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.ViewFirstProductDetails();
            Context.Assertions.ProductsAssertions.ProductDetailsExist();
            Context.ProductsPage.CloseProductDetails();
        }

        [Test]
        public void P002_OpenProductDeeplink()
        {
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.ProductsPage.ReturnToCategoryFromDeeplink();
        }
        [Test]
        public void P003_ProductsNavigation()
        {
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.ViewFirstProductDetails();
            string firstProductName = Context.ProductsPage.GetProductName();
            Context.ProductsPage.NextProduct();
            string secondProductName = Context.ProductsPage.GetProductName();
            Assert.AreNotEqual(firstProductName, secondProductName);
            Context.ProductsPage.PreviousProduct();
            secondProductName = Context.ProductsPage.GetProductName();
            Assert.AreEqual(firstProductName, secondProductName);

        }
        [Test]
        public void P004_ShareProductOnFB()
        {
            string email = Users.SocialServicesUser001.Email;
            string password = Users.SocialServicesUser001.Password;
            string description = Helpers.GetSaltWithout_Char();

            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnFB(driver, email, password, description);
        }

        [Test]
        public void P005_ShareProductOnTwitter()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnTwitter(driver, email, password, description);
        }

        [Test]
        public void P006_ShareOnPinterest()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnPinterest(driver, email, password);
        }

        [Test]
        public void P007_ShareOnTumblr()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnTumblr(driver, email, password, description);
        }
        [Test]
        public void P008_ShareOnGooglePlus()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnGPlus(email, password, description);
        }

        [Test]
        public void P009_CategoryMenu()
        {
            string category = "kids";
            string subcategory = "2-7 Boyswear";

            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenCategoryMenu();
            Context.ProductsPage.ClickCategoryInMenu(category);           
            Context.ProductsPage.ClickSubcategoryInMenu(category, subcategory);
            Context.Assertions.ProductsAssertions.CheckIfCategoryNameIs(subcategory);
        }

        [Test]
        public void P010_ProductFilters()
        {
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.ClickFilter("Men");
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.Assertions.ProductsAssertions.CheckIfProductIsInCategory("men");
        }
        [Test]
        public void P011_FindStore()
        {
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.ViewFirstProductDetails();
            Context.ProductsPage.ClickStoreLocator();
            Context.Assertions.OurStoresPageWasOpened();
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.ProductsPage.ClickStoreLocator();
            Context.Assertions.OurStoresPageWasOpened();
        }
        [Test]
        public void P012_FavouritesInDeeplink()
        {
            Context.ProductsPage.OpenProductsPage();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.ProductsPage.FavouriteProductInDeeplink();
            Context.Assertions.ProductsAssertions.FirstFavouriteWasAdded();
            Context.ProductsPage.ConfirmFirstFavourite();
            Context.Assertions.ProductsAssertions.DeeplinkFavouriteButtonIsBlue();
        }
    }
}
