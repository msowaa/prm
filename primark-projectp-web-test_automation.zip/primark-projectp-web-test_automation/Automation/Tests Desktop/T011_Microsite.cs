﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Automation.Context;
namespace Automation.TestsDesktop
{
    [TestFixture]
    class T011_Microsite : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();

        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }


        [Test]
        public void P001_ThreeColumnModule()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.ThreeColumnModuleDisplayed();
        }

        [Test]
        public void P002_ImageCarouselWithText()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.ImageCarouselWithTextDisplayed();
            Assertions.MicrositeAssertions.ImageCarouselWithTextNextArrow();
            Assertions.MicrositeAssertions.ImageCarouselWithTextPreviousArrow();
        }

        [Test]
        public void P003_ProductsBlock()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.ProductsBlockDisplayed();
        }

        [Test]
        public void P004_ProductsCarousel()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.ProductsCarouselDisplayed();
            Assertions.MicrositeAssertions.ProductsCarouselPreviousArrow();
            Assertions.MicrositeAssertions.ProductsCarouselNextArrow();
        }

        [Test]
        public void P005_HeroModuleTypeOne()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.HeroModuleTypeOneDisplayed();
        }

        [Test]
        public void P006_HeroModuleTypeTwo()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.HeroModuleTypeTwoDisplayed();
        }

        [Test]
        public void P007_TextModule()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.TextModuleDisplayed();
        }

        [Test]
        public void P008_ImageCarousel()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.ImageCarouselDisplayed();
            Assertions.MicrositeAssertions.ImageCarouselNextArrow();
            Assertions.MicrositeAssertions.ImageCarouselPreviousArrow();
        }

        [Test]
        public void P009_GoogleMap()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.GoogleMapsDisplayed();
        }

        [Test]
        public void P010_VideoPlayerModule()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.VideoPlayerModuleDisplayed();
        }

        [Test]
        public void P011_IframeModule()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.IframeModuleDisplayed();
        }

        [Test]
        public void P012_NavigationMenu()
        {
            MicrositePage.GoToMicrosite();
            Assertions.MicrositeAssertions.NavigationMenuDisplayed();
        }

    }
}
