﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;


namespace Automation.TestsDesktop
{
    //[TestFixture]
    class T010_Footer : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();

        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_CloseCookiesInformation()
        {
            Context.Assertions.FooterAssertions.CookiesInformationWasOpened();
            Context.Footer.CloseCookiesInformation();

        }


        [Test]
        public void P002_SubscribePanel()
        {
            string email = "qwerty" + Helpers.GetSaltWithout_Char() + "@asd.com";

            Context.Assertions.FooterAssertions.CookiesInformationWasOpened();
            Context.Footer.CloseCookiesInformation();

            Context.Footer.OpenSubscribePanel();
            Context.Footer.FillEmailFieldWith(email);
            Context.Footer.ClickSubscribe();

            Context.Assertions.FooterAssertions.SubscribeValidationConfirmation();

        }

        [Test]
        public void P003_SubscribePanelValidation()
        {
            string email = "qwerty";

            Context.Assertions.FooterAssertions.CookiesInformationWasOpened();
            Context.Footer.CloseCookiesInformation();

            Context.Footer.OpenSubscribePanel();
            Context.Footer.ClickSubscribe();
            Context.Assertions.FooterAssertions.SubscribeValidationEmptyEmail();

            Context.Footer.FillEmailFieldWith(email);
            Context.Footer.ClickSubscribe();
            Context.Assertions.FooterAssertions.SubscribeValidationInvalidEmail();

            email = "qwerty@asd.com";
            Context.Footer.FillEmailFieldWith(email, true);
            Context.Footer.ClickSubscribe();
            Context.Assertions.FooterAssertions.SubscribeValidationRegisteredEmail();

        }

        [Test]
        public void P004_OpenCustomerService()
        {
            Context.Footer.OpenCustomerService();
            Context.Assertions.CustomerServicePageWasOpened();
        }

        [Test]
        public void P006_OpenAboutUs()
        {
            Context.Footer.OpenAboutUs();
            Context.Assertions.AboutUsPageWasOpened();
        }

        [Test]
        public void P005_OpenCommunityGuidelines()
        {
            Context.Footer.OpenCommunityGuidelines();
            Context.Assertions.CommunityGuidelinesPageWasOpened();
        }

        [Test]

        public void P007_OpenPrivacyCookies()
        {
            Context.Footer.OpenPrivacyCookies();
            Context.Assertions.PrivaceCookiesPageWasOpened();
        }

        [Test]
        public void P008_OpenTermsOfUse()
        {
            Context.Footer.OpenTermsOfUse();
            Context.Assertions.TermsOfUsePageWasOpened();
        }


    }
}
