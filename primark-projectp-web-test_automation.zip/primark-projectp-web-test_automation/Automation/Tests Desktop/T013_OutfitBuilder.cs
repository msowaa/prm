﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;

namespace Automation.TestsDesktop
{
    class T014_OutfitBuilder : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_CreateOutfitForProfile()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;
            int newOutfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            Helpers.CreateOutfit(outfitName);
            Context.Header.ViewProfile();
            newOutfitCount = Context.ProfilePage.GetNumberOfOutfits();
            Context.Assertions.OutfitAssertions.NumberOfOutfitsIncreased(outfitCount, newOutfitCount);
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.ViewOutfitDetailsInProfile();
        }
        [Test]
        public void P002_RemoveOutfitFromProfile()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;
            int newOutfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            if (outfitCount == 0)
            {
                Helpers.CreateOutfit(outfitName);
                Context.Header.ViewProfile();
                outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            }
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.RemoveAnOutfit();            
            newOutfitCount = Context.ProfilePage.GetNumberOfOutfits();
            Context.Assertions.OutfitAssertions.NumberOfOutfitsDecreased(outfitCount, newOutfitCount);
        }
        [Test]
        public void P003_RemoveProductFromOutfit()
        {
            Context.Header.OpenProducts();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.ViewFirstProductDetails();
            Context.OutfitBuilder.ClickAddToOutfitButton();
            Context.OutfitBuilder.CreateOutfitForYourself();
            Context.Assertions.OutfitAssertions.CompleteOutfitButtonInactive();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.ProductsPage.NextProduct();
            Context.OutfitBuilder.ClickAddToOutfitButton();
            Context.Assertions.OutfitAssertions.CompleteOutfitButtonInactive();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.ProductsPage.NextProduct();
            Context.OutfitBuilder.ClickAddToOutfitButton();
            Context.Assertions.OutfitAssertions.ProductAddedToOutfit();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.Assertions.OutfitAssertions.CompleteOutfitButtonActive();
            Context.OutfitBuilder.RemoveProductFromOutfit();
            Context.Assertions.OutfitAssertions.CompleteOutfitButtonInactive();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.Assertions.OutfitAssertions.ProductNotInOutfit();
        }
        [Test]
        public void P004_CreateOutfitForChallenge()
        {
            string outfitName = Helpers.GetSalt();

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Helpers.CreateOutfit(outfitName, true);
            Context.Assertions.OutfitAssertions.OutfitNameInChallengeIs(outfitName);
            Context.OutfitBuilder.ViewOuftitDetailsInChallenge();
            Context.OutfitBuilder.BrowseAllOutfitsInChallenge();
            Context.OutfitBuilder.ClickCreateAnOutfitInChallenge();
            Context.Assertions.ProductsPageWasOpened();
            Context.Assertions.OutfitAssertions.TutorialDisplayed();
            Context.OutfitBuilder.ConfirmOutfitTutorial();
        }
        [Test]
        public void P005_FavouriteAnItemInOutfitDetailsNonSignedInUser()
        {
            int numberOfFavourites = Context.Header.FavouritesCount();

            Context.Header.OpenProducts();
            Context.ProductsPage.CloseCategoryMenu();
            Context.ProductsPage.ViewFirstProductDetails();
            Context.OutfitBuilder.ClickAddToOutfitButton();
            Context.OutfitBuilder.CreateOutfitForYourself();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.ProductsPage.NextProduct();
            Context.OutfitBuilder.ClickAddToOutfitButton();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.ProductsPage.NextProduct();
            Context.OutfitBuilder.ClickAddToOutfitButton();
            Context.OutfitBuilder.ToggleOutfitBuilderTab();
            Context.OutfitBuilder.CompleteOutfit();
            Context.OutfitBuilder.FavouriteProductInOutfitDetails();
            Context.Assertions.ProductsAssertions.ProductWasFavourited();
            Context.Assertions.HeaderAssertions.FavouritesCountEquals(numberOfFavourites + 1);
        }
        [Test]
        public void P006_FavouriteAnItemInOutfitDetailsSignedInUser()
        {
            string outfitName = Helpers.GetSalt();
            int numberOfFavourites = Context.Header.FavouritesCount();
            Assert.AreEqual(numberOfFavourites, 0);
            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            Context.ProfilePage.ViewFavouritesTab();
            Helpers.ClearFavourites(WebdriverBaseClass.driver);
            if (Context.ProfilePage.GetNumberOfOutfits() == 0)
            {
                Helpers.CreateOutfit(outfitName, true);
                Context.Assertions.OutfitAssertions.OutfitNameInChallengeIs(outfitName);
                Context.OutfitBuilder.ViewOuftitDetailsInChallenge();
            }
            else
            {
                Context.ProfilePage.ViewOutfitTab();
                Context.ProfilePage.ViewOutfitDetailsInProfile();
            }
            Context.OutfitBuilder.FavouriteProductInOutfitDetails();
            Context.Assertions.ProductsAssertions.ProductWasFavourited();
            Context.Assertions.HeaderAssertions.FavouritesCountEquals(numberOfFavourites + 1);
        }
        [Test]
        public void P007_ShareOutfitOnFacebook()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            if (outfitCount == 0)
            {
                Helpers.CreateOutfit(outfitName);
                Context.Header.ViewProfile();
            }
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.ViewOutfitDetailsInProfile();
            Helpers.ShareOnFB(driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, outfitName);
        }
        [Test]
        public void P008_ShareOutfitOnTwitter()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            if (outfitCount == 0)
            {
                Helpers.CreateOutfit(outfitName);
                Context.Header.ViewProfile();
            }
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.ViewOutfitDetailsInProfile();
            Helpers.ShareOnTwitter(driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, outfitName);
        }
        [Test]
        public void P009_ShareOutfitOnGPlus()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            if (outfitCount == 0)
            {
                Helpers.CreateOutfit(outfitName);
                Context.Header.ViewProfile();
            }
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.ViewOutfitDetailsInProfile();
            Helpers.ShareOnGPlus(Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, outfitName);
        }
        [Test]
        public void P010_ShareOutfitOnTumblr()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            if (outfitCount == 0)
            {
                Helpers.CreateOutfit(outfitName);
                Context.Header.ViewProfile();
            }
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.ViewOutfitDetailsInProfile();
            Helpers.ShareOnTumblr(driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password, outfitName);
        }
        [Test]
        public void P011_ShareOnPinterest()
        {
            string outfitName = Helpers.GetSalt();
            int outfitCount = 0;

            Helpers.SignIn(driver, Users.PrimarkUser001.Email, Users.PrimarkUser001.Password);
            Context.Header.ViewProfile();
            outfitCount = Context.ProfilePage.GetNumberOfOutfits();
            if (outfitCount == 0)
            {
                Helpers.CreateOutfit(outfitName);
                Context.Header.ViewProfile();
            }
            Context.ProfilePage.ViewOutfitTab();
            Context.ProfilePage.ViewOutfitDetailsInProfile();
            Helpers.ShareOnPinterest(driver, Users.SocialServicesUser002.Email, Users.SocialServicesUser002.Password);
        }
    }
}
