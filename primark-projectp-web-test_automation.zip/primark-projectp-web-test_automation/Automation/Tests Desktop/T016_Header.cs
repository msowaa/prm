﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Automation.TestsDesktop
{
    //[TestFixture]
    class T015_Header : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTest();

        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTest();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        { 
            base.TeardownTest();
        }

        [Test]
        public void P001_SocialFacebook()
        {
            Context.Header.SocialFacebook();
            //Context.Assertions.HeaderAssertions.SocialLinksFBWasOpened();
        }

        [Test]
        public void P002_SocialTwitter()
        {
            Context.Header.SocialTwitter();
            //Context.Assertions.HeaderAssertions.SocialLinksTwitterWasOpened();
        }

        [Test]
        public void P003_SocialPinterest()
        {
            Context.Header.SocialPinterest();
            //Context.Assertions.HeaderAssertions.SocialLinksPinterestWasOpened();
        }

        [Test]
        public void P004_SocialInstagram()
        {
            Context.Header.SocialInstagram();
            //Context.Assertions.HeaderAssertions.SocialLinksInstagramWasOpened();
        }

        [Test]
        public void P005_SocialGplus()
        {
            Context.Header.SocialGplus();
            //Context.Assertions.HeaderAssertions.SocialLinksGooglePlusWasOpened();
        }
    }
}
