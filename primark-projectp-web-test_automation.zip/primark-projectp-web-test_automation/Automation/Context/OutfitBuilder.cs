﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;

namespace Automation.Context
{
    public class OutfitBuilder
    {
        public static void ClickAddToOutfitButton()
        {
            driverExt.ClickCss(".button.button-productDetails-outfitBuilder");
            driverExt.WaitUntilElementDisappears(By.Id("overlay-outfitBuilder-blockUI"), 10);
        }
        public static void ToggleOutfitBuilderTab()
        {
            driverExt.ClickCss(".cell.panel-arrow");
            driverExt.WaitUntilElementDisappears(By.Id("overlay-outfitBuilder-blockUI"), 10);
        }
        public static void CreateOutfitForYourself()
        {
            try
            {
                driverExt.ClickCss("#button-outfitBuilder-submitToProfile", true, false);
            }
            catch
            {
                Console.WriteLine("No possibility to choose between creating outfit for yourself or for a challenge");
            }
        }
        public static void CreateOutfitForAChallenge()
        {
            driverExt.ClickCss("#button-outfitBuilder-submitToChallenge");
        }
        public static void CancelCreatingOutfit()
        {
            driverExt.ClickCss("#button-outfitBuilder-cancelDecisionTree");
        }
        public static void WhatsAChallenge()
        {
            driverExt.ClickId("link-outfitBuilder-aboutChallenge");
        }
        public static void ViewOutfitTutorial()
        {
            driverExt.ClickId("button-outfitBuilder-showTutorial");
        }
        public static void ConfirmOutfitTutorial()
        {
            driverExt.ClickId("button-outfitBuilder-hideTutorial");
        }
        public static void RemoveProductFromOutfit()
        {
            driverExt.ClickCss(".button-outfitBuilder-removeProduct");
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
        }
        public static void CompleteOutfit()
        {
            driverExt.ClickId("button-outfitbuilder-submit");
        }
        public static void SaveOutfitToProfile()
        {
            driverExt.ClickId("outfit-save-button");
        }
        public static void SubmitOutfitToChallenge()
        {
            driverExt.ClickId("outfit-submit-challenge-button");
        }
        public static void NameOutfit(string outfitName)
        {
            driverExt.FillTextField(By.Id("outfit-input-name"), outfitName);
        }
        public static void ViewOuftitDetailsInChallenge()
        {
            driverExt.ClickCss(".outfitName");
        }
        public static void BrowseAllOutfitsInChallenge()
        {
            driverExt.ClickId("button-outfit-challenge");
        }
        public static void ClickCreateAnOutfitInChallenge()
        {
            driverExt.ClickCss(".outfits-button");
        }
        public static void FavouriteProductInOutfitDetails()
        {
            driverExt.ClickCss(".button.button-favourite");
        }
        
    }
}
