﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;
using System.Text.RegularExpressions;

namespace Automation.Context
{
    public class ProfilePage
    {
        public static void ViewFavouritesTab()
        {
            driverExt.ClickId("link-profile-favourites");
        }
        public static void ViewLooksTab()
        {
            driverExt.ClickId("link-profile-looks");
        }
        public static void ViewFollowersFollowingTab()
        {
            driverExt.ClickId("link-profile-followingAndFollowers");
        }
        public static void EditDetailsTab()
        {
            driverExt.ClickId("link-profile-editDetails");
        }
        public static void ViewOutfitTab()
        {
            driverExt.ClickId("link-profile-outfits");
        }
        public static int GetNumberOfOutfits()
        {
            string outfitCount = driverExt.GetText(By.Id("profile-outfitsCount"));
            return int.Parse(outfitCount);
        }
        public static void CreateAnOutfit()
        {
            driverExt.ClickId("link-banner-outfit-first");
        }
        public static void RemoveAnOutfit()
        {
            driverExt.ClickCss(".outfit-button.delete-outfit-button");
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".link-delete-outfit-confirm"), 10);
            driverExt.WaitUntilElementIsClickable(By.CssSelector(".link-delete-outfit-confirm"), 10);
            driverExt.ClickCss(".link-delete-outfit-confirm");
            try
            {
                driverExt.WaitUntilElementDisappears(By.CssSelector(".link-delete-outfit-confirm"));
            }
            catch
            {
            }
        }
        public static void ViewOutfitDetailsInProfile()
        {
            driverExt.ClickCss(".outfitLink");
        }
        public static void UploadNewLook()
        {
            driverExt.WaitUntilElementIsPresent(By.XPath(".//*[@id='looks-container']/ul/li[1]/a/strong"), 15);
            int numberOfMyLooks = Int16.Parse(driverExt.GetText(By.XPath(".//*[@id='looks-container']/ul/li[1]/a/strong")));
            if (numberOfMyLooks == 0)
            {
                driverExt.ClickCss(".link-start-hunting");
            }
            else
            {
                driverExt.ClickCss(".link-all");//.ClickXpath(".//*[@id='looks-content']/div/div[1]/div/a");
            }
        }
        public static void OpenFirstLook()
        {
            driverExt.WaitUntilElementIsClickable(By.XPath(".//*[@id='looks-content']/div/div[2]/div[1]/a[1]"), 10);
            driverExt.ClickXpath(".//*[@id='looks-content']/div/div[2]/div[1]/a[1]");
        }
        public static void OpenFirstLookFromMyStore()
        {
            driverExt.WaitUntilElementIsClickable(By.XPath(".//*[@id='looks-content']/div/div[1]/div[1]/div[1]/a[1]"), 10);
            driverExt.ClickXpath(".//*[@id='looks-content']/div/div[1]/div[1]/div[1]/a[1]");
        }
        public static void ViewMyLooks()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-myPrimaniaLooksCount"), 15);
            driverExt.ClickId("label-profile-myPrimaniaLooksCount");
        }
        public static void ViewPrimarkedLooks()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-looksYouPrimarkedCount"), 10);
            driverExt.ClickId("label-profile-looksYouPrimarkedCount");
        }
        public static void ViewLooksFromMyStore()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-looksFromStoreCount"), 10);
            driverExt.ClickId("label-profile-looksFromStoreCount");
        }
        public static int GetMyLooksCount()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-myPrimaniaLooksCount"), 15);
            int numberOfMyLooks = Int16.Parse(driverExt.GetText(By.Id("label-profile-myPrimaniaLooksCount")));
            return numberOfMyLooks;
        }
        public static int GetPrimarkedLooksCount()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-looksYouPrimarkedCount"), 10);
            int numberOfPrimarkedLooks = Int16.Parse(driverExt.GetText(By.Id("label-profile-looksYouPrimarkedCount")));
            return numberOfPrimarkedLooks;
        }
        public static int GetLooksFromMyStoreCount()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-looksFromStoreCount"), 10);
            int numberOfMyStoreLooks = Int16.Parse(driverExt.GetText(By.Id("label-profile-looksFromStoreCount")));
            return numberOfMyStoreLooks;
        }
        public static void RemoveLook()
        {
            driverExt.ClickCss(".icon-cancel");
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".link-delete-look-confirm"), 10);
            driverExt.WaitUntilElementIsClickable(By.CssSelector(".link-delete-look-confirm"), 10);
            driverExt.ClickCss(".link-delete-look-confirm");
        }
        public static void WaitUntilLooksCounterUpdates(int waitsec = 2)
        {
            int currentLooksCount = Context.ProfilePage.GetMyLooksCount();
            int updatedLooksCount = 0;

            for (int i = 1; i < waitsec; i++)
            {
                updatedLooksCount = Context.ProfilePage.GetMyLooksCount();
                if (updatedLooksCount == currentLooksCount)
                {
                    Thread.Sleep(1000);
                }
                else
                {
                    break;
                }

            }
        }
        public static string GetUserStore()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".user-store > a.user-info-href"));
            return driverExt.GetText(By.CssSelector(".user-store > a.user-info-href")).Split('-')[0].Trim();
        }
        public static void ChangeUserNameTo(string name)
        {
            driverExt.FillTextFieldWithClear(By.Id("textbox-settings-firstName"), name);
        }
        public static void ChangeUserSurnameTo(string surname)
        {
            driverExt.FillTextFieldWithClear(By.Id("textbox-settings-lastName"), surname);
        }
        public static void ChangeUserBioTo(string bio)
        {
            driverExt.FillTextFieldWithClear(By.Id("textarea-settings-biography"), bio);
        }
        public static void ChangeUserPhoneNumberTo(string phone)
        {
            driverExt.FillTextFieldWithClear(By.Id("textbox-settings-phoneNumber"), phone);
        }
        public static void ChangeUserBlogUrlTo(string blogUrl)
        {
            driverExt.FillTextFieldWithClear(By.Id("textbox-settings-blogUrl"), blogUrl);
        }
        public static void ChangeUserCountry()
        {
            driverExt.FillTextField(By.Id("dropdown-settings-country"), OpenQA.Selenium.Keys.Return + OpenQA.Selenium.Keys.ArrowDown + OpenQA.Selenium.Keys.ArrowDown + OpenQA.Selenium.Keys.ArrowUp + OpenQA.Selenium.Keys.Return);
        }
        public static void OpenUserBlog()
        {
            driverExt.ClickCss(".user-blog-filled.user-blog>.user-info-href");
        }
        public static void SaveSettings()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("button-settings-submit"));
            driverExt.WaitUntilElementIsClickable(By.Id("button-settings-submit"));
            driverExt.ClickId("button-settings-submit");
            driverExt.WaitUntilElementIsPresent(By.Id("h3-settings-panelSaveComplete"), 10);
        }
        public static void ChangePhoto(string photoPath)
        {
            driverExt.ClickId("link-settings-changePhoto");
            driverExt.WaitUntilElementIsPresent(By.Id("button-settings-uploadFromFile"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("button-settings-uploadFromFile"), 10);
            //string js = "arguments[0].style.display='block';";          //make element visible, so that the photo can be uploaded via webdriver
            //IWebElement elem = driverExt.FindElement(By.Id("uploadPhotoInput"));
            //driverExt.ExecuteJavaScriptOnElement(js, elem);
            driverExt.SendFile(By.Id("uploadPhotoInput"), photoPath);
            driverExt.WaitUntilElementIsPresent(By.Id("_zi_icon"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("_zi_icon"), 10);

            driverExt.ClickId("button-settings-uploadDone");
        }
        public static void ChangePassword(string oldPassword, string newPassword)
        {
            driverExt.WaitUntilElementIsPresent(By.Id("link-settings-changePassword"), 10);
            driverExt.ClickId("link-settings-changePassword");
            driverExt.WaitUntilElementIsPresent(By.Id("textbox-settings-currentPassword"), 10);
            driverExt.FillTextField(By.Id("textbox-settings-currentPassword"), oldPassword);
            driverExt.FillTextField(By.Id("textbox-settings-newPassword"), newPassword);
            driverExt.FillTextField(By.Id("textbox-settings-confirmPassword"), newPassword);
        }
        public static void ChangeUserStoreMenuOpen()
        {
            driverExt.ClickId("link-settings-changeStore");
            driverExt.WaitUntilElementIsPresent(By.Id("textbox-settings-storeSearch"), 10);
        }
        public static void SearchStoreByPostcodeTownCountry(string searchText)
        {
            driverExt.FillTextField(By.Id("textbox-settings-storeSearch"), searchText);
            driverExt.ClickId("textbox-settings-storeSearch");
            driverExt.FillTextField(By.Id("textbox-settings-storeSearch"), OpenQA.Selenium.Keys.ArrowDown + OpenQA.Selenium.Keys.Return);
        }
        public static void OpenStoreSelectList()
        {
            driverExt.ClickId("store-select-list");
        }
        public static void ToggleConnectFbAccount()
        {
            driverExt.Click(By.Id("switch-settings-facebookConnected"), false);
        }
        public static void ToggleFavouritesVisibility()
        {
            driverExt.Click(By.Id("switch-settings-permissionToSeeFavorites"), false);
        }
        public static void SetPasswordAfterFbDisconnect(string newPassword)
        {
            driverExt.WaitUntilElementIsPresent(By.Id("textbox-settings-newPasswordFacebook"), 10);
            driverExt.FillTextField(By.Id("textbox-settings-newPasswordFacebook"), newPassword);
            driverExt.FillTextField(By.Id("textbox-settings-confirmPasswordFacebook"), newPassword);
        }
        public static void DeleteProfile()
        {
            driverExt.ClickId("link-settings-deleteProfile");
        }
        public static void DeleteProfileConfirm()
        {
            driverExt.Click(By.CssSelector(".button-submit"), false);
            driverExt.WaitUntilElementIsPresent(By.Id("404-error"), 10);
        }
        public static void DeleteProfileCancel()
        {
            driverExt.ClickCss(".link-cancel");
        }
        public static void RemoveFirstFavouriteClickButton()
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".button.button-favourite.favourited"), 10);
            driverExt.WaitUntilElementIsClickable(By.CssSelector(".button.button-favourite.favourited"), 10);
            driverExt.ClickCss(".button.button-favourite.favourited");
        }
        public static void RemoveFirstFavouriteConfirm()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".button.buttun-favourites-removeFavourite"), 10);
            driverExt.WaitUntilElementIsClickable(By.CssSelector(".button.buttun-favourites-removeFavourite"), 10);
            driverExt.ClickCss(".button.buttun-favourites-removeFavourite");
            driverExt.WaitForAjax(5);
        }
        public static void RemoveFirstFavouriteCancel()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".button.buttun-favourites-cancle"), 10);
            driverExt.WaitUntilElementIsClickable(By.CssSelector(".button.buttun-favourites-cancle"), 10);
            driverExt.ClickCss(".button.buttun-favourites-cancle");
        }
        public static void StartHuntingForFavourites()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".button.button-noResults"), 10);
            driverExt.ClickCss(".button.button-noResults");
        }
        public static void ClickFirstFavourite()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".image.cell"), 10);   //click favourite
            driverExt.ClickCss(".image.cell");
        }
        public static void ClickLetsAddMoreProducts()
        {
            driverExt.ClickId("link-banner-products");
        }
        public static void ClickCookieFavouritesExpirationWarning()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("button-cookieExpirationWarning-signUp"));
            driverExt.ClickId("button-cookieExpirationWarning-signUp");
        }
        public static string GetUserId()
        {
            string url = driverExt.GetUrl();
            string userId = driverExt.GetStringInBetween("/user/", "/", url, false, false); //Regex.Match(url, @"\d+").Value;
            Console.WriteLine("user id is: " + userId);
            return userId;
        }
        public static int GetFollowingCount()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-followingCount"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("label-profile-followingCount"), 10);
            int followingCount = Int16.Parse(driverExt.GetText(By.Id("label-profile-followingCount")));
            return followingCount;
        }
        public static int GetFollowersCount()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-followersCount"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("label-profile-followersCount"), 10);
            int followersCount = Int16.Parse(driverExt.GetText(By.Id("label-profile-followersCount")));
            return followersCount;

        }
        public static void ViewFollowing()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-followingCount"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("label-profile-followingCount"), 10);
            driverExt.ClickId("label-profile-followingCount");
        }
        public static void ViewFollowers()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("label-profile-followersCount"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("label-profile-followersCount"), 10);
            driverExt.ClickId("label-profile-followersCount");
        }
        public static void ClickUnfollow()
        {
            driverExt.ClickCss(".profile-unfollow-button");
        }
        public static void ClickFollow()
        {
            driverExt.ClickCss(".profile-follow-button");
        }
        public static void ViewFirstFollowingFollower()
        {
            driverExt.WaitUntilElementIsClickable(By.CssSelector(".profile-name>a"));
            driverExt.ClickCss(".profile-name>a");
        }
        public static void ClickFollowUnfollowButton()
        {
            driverExt.ClickId("user-follow-button");
        }
        public static void ClickReportUser()
        {
            driverExt.ClickId("user-report-button");
        }
        public static void GiveReasonForUserReport(string reason)
        {
            driverExt.FillTextField(By.Id("report-description"), reason);
        }
        public static void SubmitUserReport()
        {
            driverExt.ClickId("button-reportUser");
            driverExt.WaitUntilElementDisappears(By.CssSelector(".report-box.box"));
        }
        public static void CloseFavourite()
        {
            driverExt.ClickId("close-preview-button");
            
        }
    }
}
