﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class MobileMenu
    {
        public static void ToggleMenu()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("button-toogle-mobile-menu"));
            driverExt.ClickId("button-toogle-mobile-menu");
        }
        public static void OpenHomepage()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("mobileMenu-homePage-link"));
            driverExt.ClickId("mobileMenu-homePage-link");
        }
        public static void OpenFeatures()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("mobileMenu-feature-link"));
            driverExt.ClickId("mobileMenu-feature-link");
        }
        public static void OpenProducts()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("mobileMenu-products-link"));
            driverExt.ClickId("mobileMenu-products-link");
            driverExt.ClickCss(".menu-item-newarrivals");
        }
        public static void OpenPrimania()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("mobileMenu-primania-link"));
            driverExt.ClickId("mobileMenu-primania-link");
        }
        public static void OpenStores()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("mobileMenu-ourStores-link"));
            driverExt.ClickId("mobileMenu-ourStores-link");
        }
        public static void OpenOurEthics()
        {
            driverExt.WaitUntilElementIsClickable(By.Id("mobileMenu-ourEthics-link"));
            driverExt.ClickId("mobileMenu-ourEthics-link");
        }
        public static void OpenProductCategory(string category)
        {
            string convertedCategoryName = category.ToLower().Replace(' ', '-');
            driverExt.WaitUntilElementIsClickable(By.CssSelector("a[data-category='" + convertedCategoryName + "']"), 10);
            driverExt.ClickCss("a[data-category='" + convertedCategoryName + "']");
        }
        public static void OpenProductSubcategory(string category, string subcategory)
        {
            string convertedCategoryName = category.ToLower().Replace(' ', '-');
            string convertedSubcategoryName = subcategory.ToLower().Replace(' ', '-');
            driverExt.WaitUntilElementIsClickable(By.CssSelector("a[data-category='" + convertedCategoryName + "," + convertedSubcategoryName + "']"), 10);
            driverExt.ClickCss("a[data-category='" + convertedCategoryName + "," + convertedSubcategoryName + "']");
        }

    }
}
