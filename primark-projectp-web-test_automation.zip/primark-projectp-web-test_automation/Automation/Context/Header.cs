﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class Header
    {
        public static void OpenFeatures()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                MobileMenu.ToggleMenu();
                MobileMenu.OpenFeatures();
            }
            else
            {
                driverExt.ClickId("header-feature-link");
            }
        }
        public static void OpenProducts()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                MobileMenu.ToggleMenu();
                MobileMenu.OpenProducts();
            }
            else
            {
                driverExt.ClickId("header-products-link");
            }

        }
        public static void OpenPrimania()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                MobileMenu.ToggleMenu();
                MobileMenu.OpenPrimania();
            }
            else
            {
                driverExt.ClickId("header-primania-link");
            }
        }
        public static void OpenOurStores()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                MobileMenu.ToggleMenu();
                MobileMenu.OpenStores();
            }
            else
            {
                driverExt.ClickId("header-ourStores-link");
            }

        }
        public static void OpenOurEthics()
        {
            driverExt.ClickId("header-ourEthic-link");            
        }
        public static void OpenHomepage()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                MobileMenu.ToggleMenu();
                MobileMenu.OpenHomepage();
            }
            else
            {
                driverExt.ClickId("logo");
            }
        }
        public static void ViewProfile()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickId("link-userProfile");
            }
            else
            {
                driverExt.ClickCss(".menu-primark");
                driverExt.ClickId("link-profilePage");
            }

        }
        public static void EditProfile()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                ViewProfile();
                driverExt.ClickId("link-profile-editDetails");
            }
            else
            {
                driverExt.ClickCss(".menu-primark");
                driverExt.ClickCss("#edit-my-profile>a");
            }

        }
        public static void SignOut()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                ViewProfile();
                driverExt.ClickId("button-logOff");
            }
            else
            {
                driverExt.ClickCss(".menu-primark");
                driverExt.WaitUntilElementIsPresent(By.CssSelector("#signOut-my-profile>a"));
                driverExt.WaitUntilElementIsClickable(By.CssSelector("#signOut-my-profile>a"));
                driverExt.ClickCss("#signOut-my-profile>a");
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".my-primark.logged-out"));
            }
        }
        public static void SignIn()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.Id("m-user-links"));
                driverExt.ClickId("m-user-links");
                Context.SignInSignUpPage.ChooseSignIn();
            }
            else
            {
                driverExt.ClickId("login-link");
            }
        }
        public static void SignUp()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.Id("m-user-links"));
                driverExt.WaitUntilElementIsClickable(By.Id("m-user-links"));
                driverExt.ClickId("m-user-links");
                Context.SignInSignUpPage.ChooseSignUp();
            }
            else
            {
                driverExt.ClickId("register-link");
            }
        }
        public static int FavouritesCount()
        {
            
            driverExt.WaitForAjax(5);
            int favCount;
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobile-header"), By.CssSelector(".count"));
                favCount = Int16.Parse(driverExt.GetText(By.CssSelector(".mobile-header"), By.CssSelector(".count")));
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".desktop-header"), By.CssSelector(".count"));
                favCount = Int16.Parse(driverExt.GetText(By.CssSelector(".desktop-header"), By.CssSelector(".count")));
            }
            return favCount;
        }
        public static void ClickFavouritesButton()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                //driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobile-header"), By.CssSelector(".button-favourites"));
                //driverExt.Click(driverExt.FindElement(By.CssSelector(".mobile-header")), By.CssSelector(".favourites-container"));
                driverExt.OpenUrl(WebdriverBaseClass.url + "/en/account/favourites");
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".desktop-header"), By.CssSelector(".button-favourites"));
                driverExt.ClickFirstVisibleElement(By.CssSelector(".favourites-li-element"));
            }
        }
        public static void OpenSearchOverlay()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".cell>ul>li>.search-button");
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            }
            else
            {
                driverExt.ClickCss(".right.search-button");
            }
        }
        public static void SocialFacebook()
        {
            driverExt.ClickCss(".icon-facebook");
        }
        public static void SocialTwitter()
        {
            driverExt.ClickCss(".icon-twitter-bird");
        }
        public static void SocialPinterest()
        {
            driverExt.ClickCss(".icon-pinterest");
        }
        public static void SocialInstagram()
        {
            driverExt.ClickCss(".icon-instagram");
        }
        public static void SocialGplus()
        {
            driverExt.ClickCss(".icon-gplus");
        }

    }
}
