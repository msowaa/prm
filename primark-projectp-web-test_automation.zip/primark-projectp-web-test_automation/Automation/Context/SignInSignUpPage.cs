﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class SignInSignUpPage
    {
        public static void ChooseSignIn()
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickFirstVisibleElement(By.CssSelector(".button-activeLoginArea"));
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.left"), By.CssSelector(".loginArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.Click(driverExt.FindElement(By.CssSelector(".mobileCard")), By.CssSelector(".button-activeLoginArea"));
                driverExt.WaitUntilElementIsPresent(By.Id("fb-login"));
            }
        }
        public static void ChooseSignUp()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".button-activeRegistrationArea"));
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right"), By.CssSelector(".registrationArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                //driverExt.Click(driverExt.FindElement(By.CssSelector(".mobileCard")), By.CssSelector(".button-activeRegistrationArea"));
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".registrationArea.transition-05s>.box>.table>.cell>#facebook-sign-in"));
            }
        }
        public static void FillEmailSignInFieldWith(string email, bool clear = false)
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.left"), By.CssSelector(".loginArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".loginArea.transition-05s"), 5);
            }
            if (clear)
            {
                driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signIn-email")).Clear();
            }
            driverExt.FillTextField(By.CssSelector(".card.left>.loginArea.transition-05s>.loginToProfile.box>.table>.cell>form>.textfieldBox>.textfield.textbox-signIn-email"), email);
        }
        public static void FillPasswordSignInFieldWith(string password)
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.left"), By.CssSelector(".loginArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".loginArea.transition-05s"), 5);
            }
            driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signIn-password")).SendKeys(password);
        }
        public static void ClickSignIn()
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.left"), By.CssSelector(".loginArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".loginArea.transition-05s"), 5);
            }
            driverExt.ClickFirstVisibleElement(By.CssSelector(".button-signIn-submit"));
        }
        public static void FillNameFieldWith(string name, bool clear = false)
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right"), By.CssSelector(".registrationArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".registrationArea.transition-05s"), 5);
            }
            if (clear)
            {
                driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-firstName")).Clear();
            }
            driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-firstName")).SendKeys(name);
        }
        public static void FillEmailSignUpFieldWith(string email, bool clear = false)
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right"), By.CssSelector(".registrationArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".registrationArea.transition-05s"), 5);
            }
            if (clear)
            {
                driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-email")).Clear();
            }
            driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-email")).SendKeys(email);
        }
        public static void FillConfirmEmailSignUpFieldWith(string email, bool clear = false)
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right"), By.CssSelector(".registrationArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".registrationArea.transition-05s"), 5);
            }
            if (clear)
            {
                driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-confirmEmail")).Clear();
            }
            driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-confirmEmail")).SendKeys(email);
        }
        public static void FillPasswordSignUpFieldWith(string password, bool clear = false)
        {
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right"), By.CssSelector(".registrationArea.transition-05s"), 5);//todo: implement mobile version
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".registrationArea.transition-05s"), 5);
            }
            if (clear)
            {
                driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-password")).Clear();
            }
            driverExt.FindFirstVisibleElement(By.CssSelector(".textbox-signUp-password")).SendKeys(password);
        }
        public static void ClickSignUp()
        {            
            if (!WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right"), By.CssSelector(".registrationArea.transition-05s"), 5);//todo: implement mobile version
                if (driverExt.GetUrl().Contains("en-us"))
                {
                    driverExt.Click(driverExt.FindElement(By.CssSelector(".card.right")), By.CssSelector(".container-checkbox>label"));
                }
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".mobileCard"), By.CssSelector(".registrationArea.transition-05s"), 5);
                if (driverExt.GetUrl().ToLower().Contains("/en-us"))
                {
                    driverExt.Click(driverExt.FindElement(By.CssSelector(".mobileCard")), By.CssSelector(".container-checkbox > label.checkbox"));
                }
            }
            driverExt.ClickFirstVisibleElement(By.CssSelector(".button-signUp-submit"));
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            
        }
        public static void SignupConfirmed()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".welcomeMessageArea.transition-05s>.box>.table>.cell>h1"));
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".card.right>.welcomeMessageArea.transition-05s>.box>.table>.cell>.m-b-big.w-m-sbottom"));
            }
        }
    }
}
