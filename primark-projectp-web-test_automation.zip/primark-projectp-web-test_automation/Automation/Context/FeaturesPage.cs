﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class FeaturesPage
    {
        public static void ViewFirstTopCarouselItem(bool click = false)
        {
            driverExt.ClickCss(".slick-dots>li:nth-child(1)>.page-button");
            if (click)
            {
                driverExt.ClickCss(".slick-track>div:nth-child(1)>.linkToFeatures.redirectURL");
            }
        }
        public static void ViewSecondTopCarouselItem(bool click = false)
        {
            driverExt.ClickCss(".slick-dots>li:nth-child(2)>.page-button");
            if (click)
            {
                driverExt.ClickCss(".slick-track>div:nth-child(2)>.linkToFeatures.redirectURL");
            }
        }
        public static void ViewThirdTopCarouselItem(bool click = false)
        {
            driverExt.ClickCss(".slick-dots>li:nth-child(3)>.page-button");
            if (click)
            {
                driverExt.ClickCss(".slick-track>div:nth-child(3)>.linkToFeatures.redirectURL");
            }
        }
        public static void ClickNextTopCarouselItem()
        {
            driverExt.ClickCss(".slick-next");
        }
        public static void ClickPreviousTopCarouselItem()
        {
            driverExt.ClickCss(".slick-prev");
        }
        public static void OpenFirstFeatureFromFourRowContainer()
        {
            IWebElement fourRowContainer = driverExt.FindElement(By.CssSelector(".featureFourRowsContainer"));
            driverExt.Click(fourRowContainer, By.CssSelector(".cta-link.redirectURL"));
            //driverExt.ClickCss(".featureFourRowsContainer.featureFourRows-table>.cell>.featureTwoRows-table>.featureRow.cell.feature-1>.buttonBox.feature-1>.box-ctaButton.feature-button.redirectURL");
        }
        public static void OpenFirstFeatureFromTwoRowContainer()
        {
            IWebElement twoRowContainer = driverExt.FindElement(By.CssSelector(".featureTwoRowsContainer"));
            driverExt.Click(twoRowContainer, By.CssSelector(".cta-link.redirectURL"));
            //driverExt.ClickCss(".featureTwoRowsContainer.featureRows-table>.featureRow.featureRow-column-cell.feature-1>.buttonBox>.box-ctaButton.feature-button.redirectURL");
        }
        public static void OpenFeatureFrom3To1Container()
        {
            IWebElement videoContainer = driverExt.FindElement(By.CssSelector(".videoImageRow3To1"));
            driverExt.Click(videoContainer, By.CssSelector(".box-ctaButton.feature-button.redirectURL"));
            //driverExt.ClickCss(".videoImageRow3To1>.imageVideo-descriptionBox.layout-3-1>.table>.cell>.box-ctaButton.feature-button.redirectURL");
        }
        public static void SelectFilter(string filterName)
        {
            driverExt.ClickCss("a[href='/en/features/" + filterName.ToLower() + "']");
        }
        public static void NextFeature()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                IWebElement featureHeader = driverExt.FindElement(By.Id("features-header"));
                driverExt.Click(featureHeader, By.Id("navigation-category-next"));
            }
            else
            {
                driverExt.ClickCss("#navigation-allCategories-next>.next-arrow>.arrow-text");
            }
        }
        public static void PreviousFeature()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                IWebElement featureHeader = driverExt.FindElement(By.Id("features-header"));
                driverExt.Click(featureHeader, By.Id("navigation-category-prev"));
            }
            else
            {
                driverExt.ClickCss("#navigation-allCategories-prev>.prev-arrow>.arrow-text");
            }
        }
        public static void ClickFollowUnfollowEditorButton()
        {
            driverExt.ClickId("author-follow-button");
        }
        public static void LoadMore()
        {
            driverExt.ClickId("features-load-more");
        }
    }
}
