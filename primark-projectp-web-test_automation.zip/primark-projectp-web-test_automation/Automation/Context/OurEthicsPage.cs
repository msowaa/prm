﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class OurEthicsPage
    {
        public static string GetQuestionText()
        {
            string questionText = driverExt.GetText(By.CssSelector(".title-level-1"));
            return questionText;
        }
        public static void NextQuestion()
        {
            driverExt.ClickCss(".nav.next.active.car");
            Thread.Sleep(1000);
        }
        public static void PreviousQuestion()
        {
            driverExt.ClickCss(".nav.prev.active.car");
            Thread.Sleep(1000);
        }
        public static void NextQuestionDeeplink()
        {
            driverExt.ClickCss(".nav.next");
        }
        public static void PreviousQuestionDeeplink()
        {
            driverExt.ClickCss(".nav.prev");
        }
        public static void QuestionFindOut()
        {
            driverExt.ClickCss(".btn.border_box");
        }
        public static void OpenExampleArticleInDeeplink()
        {
            Helpers.HideHeader();
            Helpers.HideFooter();
            driverExt.ClickCss(".btn_read_more.border_box.blue_dk");
        }
        public static void OpenExampleArticleInOverlay()
        {
            Helpers.HideHeader();
            Helpers.HideFooter();
            driverExt.ClickCss(".overlay_lnk_actuator>img");
            Thread.Sleep(2000); //until double overlay loading bug isn't fixed
        }
    }
}
