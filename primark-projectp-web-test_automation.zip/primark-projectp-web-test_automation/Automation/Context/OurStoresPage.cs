﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;



namespace Automation.Context
{
    public class OurStoresPage
    {
        public static void ClickLocateNearestStore()
        {
            driverExt.ClickId("locate-nearest-store-button");
            if (WebdriverBaseClass.IsMobile)
            {
                //var actionTap = new TouchActions(WebdriverBaseClass.driver).
                Thread.Sleep(2000);
                /*IAlert alert = WebdriverBaseClass.driver.SwitchTo().Alert();
                alert.Accept();*/
            }
        }
        public static void WaitForStoresListLoad()
        {
            driverExt.WaitForLoading(By.Id("AddressTextBox"));
        }
        public static void OpenFirstStoreDetails()
        {
            Context.OurStoresPage.WaitForStoresListLoad();
            driverExt.ClickCss(".button.bg-green-dark.store-more-details-button");
        }
        public static void SearchForStore(string store)
        {
            driverExt.WaitUntilElementIsPresent(By.Id("AddressTextBox"), 10);
            driverExt.WaitUntilElementIsClickable(By.Id("AddressTextBox"), 10);
            
            if (WebdriverBaseClass.IsMobile)
            {
                string currentFirstStore = driverExt.GetText(By.CssSelector(".store-box.bg-turquoise>.store-box-details>.title-level-3"));
                string updatedFirstStore = driverExt.GetText(By.CssSelector(".store-box.bg-turquoise>.store-box-details>.title-level-3"));
                driverExt.FillTextField(By.Id("AddressTextBox"), store, true);
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                while (currentFirstStore == updatedFirstStore)
                {
                    updatedFirstStore = driverExt.GetText(By.CssSelector(".store-box.bg-turquoise>.store-box-details>.title-level-3"));
                    Thread.Sleep(100);                    
                }
            }
            else
            {
                driverExt.FillTextField(By.Id("AddressTextBox"), store);
                driverExt.FindElement(By.CssSelector(".our-stores-overlay"));
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".button.bg-green-dark.store-more-details-button"), 10);
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".button.bg-green-dark.store-more-details-button"), 10);
            }
        }
        public static void SetAsMyPrimark()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".my-primark.ui-link"), 10);
                driverExt.ClickCss(".my-primark.ui-link");
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".set-my-primark-button.button"), 10);
                driverExt.ClickCss(".set-my-primark-button.button");
            }
        }
        public static string GetStoreName()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                string result = driverExt.GetPageTitle().Split(':')[1].Trim();
                return result;
            }
            else
            {
                return driverExt.GetText(By.CssSelector(".title-level-1"));
            }
        }
        public static void OpenFirstProductInStore()
        {
            driverExt.ClickCss(".store-product");
        }
        public static void ClickViewLatestProductsButton()
        {
            Helpers.HideHeader();
            Helpers.HideFooter();
            driverExt.ClickCss(".button.products-button");
        }
        public static void FavouriteAProductInStore()
        {
            driverExt.ClickCss(".button.button-favourite");
        }
        public static void UnfavouriteAProductInStore()
        {
            driverExt.ClickCss(".button.button-favourite.favourited");
        }
    }
}
