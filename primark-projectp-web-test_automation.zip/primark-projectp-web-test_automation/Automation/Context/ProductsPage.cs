﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class ProductsPage
    {
        public static void OpenProductsPage()
        {
            driverExt.ClickId("header-products-link");
        }
        public static void CloseCategoryMenu()
        {
            try
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".button-toogle-menu.active.open"), 10);
                driverExt.ClickCss(".button-toogle-menu.active.open");
            }
            catch
            {

            }
        }
        public static void OpenCategoryMenu()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".button-toogle-menu"), 10);
            driverExt.ClickCss(".button-toogle-menu");
        }
        public static void ViewFirstProductDetails()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".product-container.table"), 10);
            driverExt.ClickCss(".image.cell");
        }
        public static void NextProduct()
        {
            driverExt.ClickId("next-product-button");
        }
        public static void PreviousProduct()
        {
            driverExt.ClickId("prev-product-button");
        }
        public static void CloseProductDetails()
        {
            driverExt.ClickId("close-preview-button");
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
        }
        public static void OpenFirstProductDeeplink()
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            Context.ProductsPage.ViewFirstProductDetails();
            string url = driverExt.GetUrl();
            driverExt.OpenUrl(url);
        }
        public static void ReturnToCategoryFromDeeplink()
        {
            driverExt.ClickCss(".category-link>a");
        }
        public static string GetProductName()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".cell>h3"), 10);
            return driverExt.GetText(By.CssSelector(".cell>h3"));
        }
        public static void ClickCategoryInMenu(string category)
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            string convertedCategoryName = category.ToLower().Replace(' ', '-');
            driverExt.WaitUntilElementIsPresent(By.CssSelector("a[data-category='" + convertedCategoryName + "']"), 10);
            driverExt.ClickFirstVisibleElement(By.CssSelector("a[data-category='" + convertedCategoryName + "']"));
        }
        public static void ClickSubcategoryInMenu(string category, string subcategory)
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            string convertedCategoryName = category.ToLower().Replace(' ', '-');
            string convertedSubcategoryName = subcategory.ToLower().Replace(' ', '-');
            driverExt.WaitUntilElementIsPresent(By.CssSelector("a[data-category='" + convertedCategoryName + "," + convertedSubcategoryName + "']"), 10);
            driverExt.ClickFirstVisibleElement(By.CssSelector("a[data-category='" + convertedCategoryName + "," + convertedSubcategoryName + "']"));
        }
        public static void ClickFilter(string filter)
        {
            string convertedFilterName = filter.ToLower().Replace(' ', '-');
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".new-arrivals-links>li>a[data-category*='" + convertedFilterName + "']"), 10);
            driverExt.ClickCss(".new-arrivals-links>li>a[data-category*='" + convertedFilterName + "']");
        }
        public static void ClickStoreLocator()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".store-locator>a"), 10);
            driverExt.ClickCss(".store-locator>a");
        }
        public static void FavouriteFirstProduct()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".button.button-favourite"), 10);
            driverExt.ClickCss(".button.button-favourite");
        }
        public static void FavouriteProductInDeeplink()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector("button.button.button-productDetails-favourite"));
        }
        public static void ConfirmFirstFavourite()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("arrow-firstFavourite"), 10);
            driverExt.ClickCss(".button.button-firstFavourite");
        }
    }
}
