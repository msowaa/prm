﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class QuizPage
    {
        public static void OpenQuizPage(string quizName = "quizpn", string language = "en")
        {
            driverExt.OpenUrl(WebdriverBaseClass.AppUrl + language + "/quiz/" + quizName);
        }
        public static void ChooseQuizPage(string quizPageName)
        {
            driverExt.Click(By.CssSelector("a[href*='" + quizPageName + "']"));
        }
        public static void ChooseImageAnswerNumber(int answerNumber)
        {
            driverExt.ClickCss(".container-answers.clearfix.count-3>.answer.answer-image:nth-child(" + answerNumber + ")>.overlay-selection>.selection");
        }
        public static void ChoosePhraseAnswerNumber(int answerNumber)
        {
            driverExt.ClickCss(".answer.answer-phrase:nth-child(" + answerNumber + ")>.table>.cell.text-answer");
        }
        public static void NextQuestion()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".button-quiz-arrow-next"));
        }
        public static void PreviousQuestion()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".button-quiz-arrow-prev"));
        }
        public static void ClickResultButton()
        {
            driverExt.ClickCss(".button.button-arrow.button-quizResultPage");
        }


    }
}
