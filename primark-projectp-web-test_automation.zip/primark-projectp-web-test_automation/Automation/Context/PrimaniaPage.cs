﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;


namespace Automation.Context
{
    public class PrimaniaPage
    {     
        public static void OpenAddedLook()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".header>.title"), 10);
                driverExt.ClickCss(".just-uploaded-look");
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".title-level-2.headder"), 10);
                driverExt.ClickId("just-uploaded-look-image");
            }
        }
        public static void OpenFilters()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickId("button-filterToggle");
                driverExt.WaitUntilElementIsPresent(By.Id("apply-filters"), 10);
                driverExt.WaitUntilElementIsClickable(By.Id("apply-filters"), 10);
            }
            else
            {
                driverExt.ClickId("filter_toggle");
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".filter-label.checkbox"), 10);
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".filter-label.checkbox"), 10);
            }

        }
        public static void ChooseCasualFilter()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickXpath(".//select[@name='situation']");
                driverExt.ClickXpath(".//select[@name='situation']/option[@value='1']");
                driverExt.ClickId("apply-filters");
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                driverExt.WaitUntilElementDisappears(By.Id("fix-overlay"));
            }
            else
            {
                driverExt.ClickXpath(".//*[@id='filter_trend']/div[2]/div/span[1]/label");
                driverExt.ClickId("filter_toggle");
                driverExt.WaitUntilElementIsPresent(By.Id("situation1_cross"), 10);
                driverExt.WaitUntilElementIsClickable(By.Id("situation1_cross"), 10);
            }

        }
        public static void OpenFirstLook()
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector("#container > div:nth-child(1) > div.extra-container"), 10);
                driverExt.WaitUntilElementIsClickable(By.CssSelector("#container > div:nth-child(1) > div.extra-container"), 10);
                driverExt.ClickCss("#container > div:nth-child(1) > div.extra-container");
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".primark-button"));
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".image"), 10);
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".image"), 10);
                driverExt.ClickCss(".image");
                driverExt.WaitUntilElementIsPresent(By.Id("look-overlay"), 10);
            }

        }
        public static void OpenFirstLookDeeplink()
        {
            Context.PrimaniaPage.OpenFirstLook();
            string lookUrl = driverExt.GetUrl();
            driverExt.OpenUrl(lookUrl);
        }
        public static void OpenFirstFilteredLook()
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector("#container > div:nth-child(1) > div.extra-container"), 10);
                driverExt.WaitUntilElementIsClickable(By.CssSelector("#container > div:nth-child(1) > div.extra-container"), 10);
                string lookId = driverExt.GetAttributeOf(By.CssSelector("#container > div:nth-child(1)"), "data-item-id");
                Console.WriteLine(lookId);
                driverExt.OpenUrl(WebdriverBaseClass.AppUrl + "en/primania/look/" + lookId);
                driverExt.WaitUntilElementIsPresent(By.CssSelector("#container > div.primarking > div > div > div.primark-button.none"));
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".image"), 10);
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".image"), 10);
                driverExt.ClickCss(".image");
                driverExt.WaitUntilElementIsPresent(By.Id("look-overlay"), 10);
            }
        }
        public static void CloseLook()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                Header.OpenPrimania();
            }
            else
            {
                driverExt.ClickCss(".icon-close");
            }
        }
        public static void RemoveFilter()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickId("clear-filters");
                driverExt.ClickId("apply-filters");
                driverExt.WaitUntilElementDisappears(By.Id("apply-filters"));
            }
            else
            {
                driverExt.WaitUntilElementIsClickable(By.Id("situation1_cross"), 10);
                driverExt.ClickId("situation1_cross");
            }

        }
        public static void SortByPopularity()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                OpenFilters();
                driverExt.WaitUntilElementIsClickable(By.Id("filter-sort-by"));
                driverExt.ClickId("filter-sort-by");
                driverExt.ClickXpath(".//select[@id='filter-sort-by']/option[@value='6']");
            }
            else
            {
                driverExt.WaitUntilElementIsClickable(By.Id("sort-by-popularity"), 10);
                driverExt.ClickId("sort-by-popularity");
            }

        }
        public static void SortByDate()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                OpenFilters();
                driverExt.WaitUntilElementIsClickable(By.Id("filter-sort-by"));
                driverExt.ClickId("filter-sort-by");
                driverExt.ClickXpath(".//select[@id='filter-sort-by']/option[@value='3']");
            }
            else
            {
                driverExt.WaitUntilElementIsClickable(By.Id("sort-by-date"), 10);
                driverExt.ClickId("sort-by-date");
            }

        }
        public static void ReportLook(string report)
        {
            if (WebdriverBaseClass.IsMobile)
            {
                while (true)
                {
                    try
                    {
                        driverExt.WaitUntilElementIsPresent(By.CssSelector("div#container>div.primarking>div.bar>div.inner>div#report-user.report-link"));
                        driverExt.WaitUntilElementIsClickable(By.CssSelector("div#container>div.primarking>div.bar>div.inner>div#report-user.report-link"));
                        driverExt.ClickCss("div#container>div.primarking>div.bar>div.inner>div#report-user.report-link");
                        break;
                    }
                    catch
                    {
                        driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                        NextLook();
                    }
                }
            }
            else
            {
                while (driverExt.GetText(By.Id("report-link")) != "Report this look")
                {
                    NextLook();
                    driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);

                    if (!driverExt.ElementDisplayed(By.Id("report-link")))
                    {
                        NextLook();
                    }

                }

                driverExt.ClickId("report-link");
            }

            driverExt.FillTextField(By.Id("description"), report);

            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickId("submit-reporting-user");
                Context.Assertions.PrimaniaAssertions.LookWasReported();
                driverExt.WaitUntilElementIsPresent(By.Id("done-reporting-user"), 10);
                driverExt.ClickId("done-reporting-user");
            }
            else
            {
                driverExt.ClickId("submit-report-button");
                driverExt.WaitUntilElementIsPresent(By.Id("done-report-button"), 10);
                Context.Assertions.PrimaniaAssertions.LookWasReported();
                driverExt.ClickId("done-report-button");
            }



        }
        public static void NextLook()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".next-primania"));
                driverExt.ClickCss(".next-primania");
            }
            else
            {
                driverExt.ClickCss(".next-look");
                driverExt.WaitUntilElementIsPresent(By.Id("overlay-content"));
            }
            driverExt.WaitForAjax(5);
        }
        public static void PreviousLook()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".prev-primania"));
                driverExt.ClickCss(".prev-primania");
            }
            else
            {
                driverExt.ClickCss(".previous-look");
                driverExt.WaitUntilElementIsPresent(By.Id("overlay-content"), 10);
            }
            driverExt.WaitForAjax(5);
        }
        public static void FindLookWithoutPrimarks()
        {
            bool lookWithoutPrimarks = false;
            string primarkButtonText;

            if (WebdriverBaseClass.IsMobile)
            {
                primarkButtonText = driverExt.GetText(By.CssSelector(".primarking>.bar>.inner>div:nth-child(2)>.text"));
            }
            else
            {
                primarkButtonText = driverExt.GetText(By.CssSelector(".text"));
            }

            while (lookWithoutPrimarks == false)
            {
                if (primarkButtonText.Contains("GIVE 'EM PRI"))
                {
                    Console.WriteLine("look wasn't given primarks by this user - giving primarks now");
                    lookWithoutPrimarks = true;
                }
                else
                {
                    Console.WriteLine("look already has primarks - moving to next look");
                    if (WebdriverBaseClass.IsMobile)
                    {
                        NextLook();
                        driverExt.WaitUntilElementIsPresent(By.XPath(".//*[@id='container']/div[1]/div[2]/img"), 5);    //look load
                        primarkButtonText = driverExt.GetText(By.CssSelector(".primarking>.bar>.inner>div:nth-child(2)>.text"));
                    }
                    else
                    {
                        NextLook();
                        driverExt.WaitUntilElementIsPresent(By.XPath(".//*[@id='overlay-preloader']/div"), 5);    //look load
                        driverExt.WaitUntilElementIsPresent(By.Id("look-overlay"), 10);
                        primarkButtonText = driverExt.GetText(By.CssSelector(".text"));
                    }
                    //Thread.Sleep(100);

                }
            }
        }
        public static void GivePrimarks()
        {
            driverExt.ClickCss(".primark-button");
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector("div[class='primark-button liked']"));
            }
            else
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector("div[class='primark-button like']"));
            }
        }
        public static void RemovePrimarks()
        {
            driverExt.ClickCss(".primark-button");
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector("div[class='primark-button unliked']"));
            }
            else
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector("div[class='primark-button unlike']"));
            }
        }
        public static void ClickLookUpload()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".upload-button.ui-link");
            }
            else
            {
                driverExt.ClickId("link-primania-uploadYourLook");
            }
        }
        public static void UploadPhotoToLook(string path)
        {
            driverExt.SendFile(By.Id("look-file"), path);
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementDisappears(By.Id("cancel-look-upload"));
            }

        }
        public static void ClickNextAfterUpload()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.Id("next-step-3"), 120);
                driverExt.WaitUntilElementIsClickable(By.Id("next-step-3"), 5);
                driverExt.ClickId("next-step-3");
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.Id("btnCropNext"), 120);
                driverExt.WaitUntilElementIsClickable(By.Id("btnCropNext"), 5);
                driverExt.ClickId("btnCropNext");
            }
        }
        public static void TagItem(string itemName, string itemPrice)
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsClickable(By.Id("image-tagging"));
                driverExt.ClickId("image-tagging");
                driverExt.FillTextField(By.Id("item-price"), itemPrice);
                driverExt.FillTextField(By.Id("item-name"), itemName);
                driverExt.ClickId("add-tag");
            }
            else
            {
                driverExt.ClickId("after-crop-image");
                driverExt.FillTextField(By.Id("item-name"), itemName);
                driverExt.FillTextField(By.Id("item-price"), itemPrice);
                driverExt.ClickId("item-tag-done");
            }
        }
        public static void ClickNextAfterTagging()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.Id("next-step-5"));
                driverExt.WaitUntilElementIsClickable(By.Id("next-step-5"));
                driverExt.ClickId("next-step-5");
                driverExt.WaitUntilElementIsClickable(By.Id("next-step-6"));
                driverExt.ClickId("next-step-6");
            }
            else
            {
                driverExt.ClickId("btn-tag-next");
            }
        }
        public static void FinalizeLookUpload(string description)
        {
            driverExt.ClickCss(".checkbox");
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".trend");
                driverExt.FillTextField(By.Id("look-situation"), description);
                driverExt.WaitUntilElementIsClickable(By.CssSelector("#next-step-7.active"));
                driverExt.ClickCss("#next-step-7");
            }
            else
            {
                driverExt.ClickId("label_situation_1");
                driverExt.FillTextField(By.Id("description"), description);
                driverExt.ClickId("btnSubmit");
            }
        }
        public static void OpenLookWithId(string id)
        {
            driverExt.OpenUrl(WebdriverBaseClass.AppUrl + "en/primania/look/" + id);
        }
        public static void ClickFollow()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickId("follow-user-button");
            }
            else
            {
                driverExt.ClickId("follow-button-look");
            }
        }

    }
}
