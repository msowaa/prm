﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using NUnit.Framework;
using System.Threading;

namespace Automation.Context
{
    class Assertions : WebdriverBaseClass
    {
        public class ProductsAssertions : Assertions
        {
            public static void ProductDetailsExist()
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".cell>h3"), 10);
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".price"), 10);
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".date"), 10);
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".store-locator>a"), 10);
            }
            public static void CheckIfCategoryNameIs(string category)
            {
                string convertedCategoryName = category.ToUpper();
                string currentCategoryName = driverExt.GetText(By.CssSelector("#category-title>h1"));
                Console.WriteLine("category name should be: " + category);
                Console.WriteLine("category name is: " + currentCategoryName);
                Assert.IsTrue(currentCategoryName.Contains(convertedCategoryName));
            }
            public static void CheckIfProductIsInCategory(string category)
            {
                string showAllLink = driverExt.GetLink(By.CssSelector(".category-link>a"));
                Assert.IsTrue(showAllLink.Contains(category));
            }
            public static void OurStoresWasOpened()
            {
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("our-stores"));
            }
            public static void DeeplinkWasOpended()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".category-link>a")));
            }
            public static void FirstFavouriteWasAdded()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".button.button-firstFavourite")));
                Context.Assertions.StringsAreEqual(driverExt.GetText(By.CssSelector(".count")), "1");
            }
            public static void DeeplinkFavouriteButtonIsBlue()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                driverExt.FindElement(By.CssSelector(".button.button-productDetails-favourite.favourited"));
            }
            public static void ProductWasFavourited()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                driverExt.FindElement(By.CssSelector(".button.button-favourite.favourited"));
            }
            public static void ProductWasUnfavourited()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                driverExt.FindElement(By.CssSelector(".button.button-favourite"));
            }
        }
        public class PrimaniaAssertions : Assertions
        {
            public static void CheckIfLookPriceIs(string itemPrice)
            {
                string checkPrice = "";
                if (WebdriverBaseClass.IsMobile)
                {
                    for (int i = 1; i < 5; i++)
                    {
                        checkPrice = driverExt.GetText(By.CssSelector(".primark-item>.price"));
                        if (checkPrice != "")
                        {
                            break;
                        }
                    }
                }
                else
                {
                    checkPrice = driverExt.GetText(By.XPath(".//*[@id='look-overlay']/div/div[2]/div/div[2]/div[2]/div/div[2]"));
                }
                Console.WriteLine("price should be: " + itemPrice);
                Console.WriteLine("price is: " + checkPrice);

                if (checkPrice.Contains(itemPrice))
                {
                    Console.WriteLine("price OK");
                }
                else
                {
                    Assert.Fail("wrong item price");
                }

            }
            public static void CheckIfLookNameIs(string itemName)
            {
                string checkName = driverExt.GetText(By.XPath(".//*[@id='look-overlay']/div/div[2]/div/div[2]/div[2]/div/div[1]"));
                Console.WriteLine("name should be: " + itemName);
                Console.WriteLine("name is: " + checkName);

                if (checkName.Contains(itemName))
                {
                    Console.WriteLine("name OK");
                }
                else
                {
                    Assert.Fail("wrong item name");
                }

            }
            public static void CheckIfLookDescriptionIs(string description)
            {
                string checkDesc = "";

                if (WebdriverBaseClass.IsMobile)
                {
                    checkDesc = driverExt.GetText(By.CssSelector(".situation>.description"));
                }
                else
                {
                    checkDesc = driverExt.GetText(By.CssSelector(".where-text"));
                }

                Console.WriteLine("'Where did you wear this?' should be: " + description);
                Console.WriteLine("'Where did you wear this?' is: " + checkDesc);

                if (checkDesc.Contains(description))
                {
                    Console.WriteLine("'Where did you wear this?' OK");
                }
                else
                {
                    Assert.Fail("'Where did you wear this?' wrong");
                }
            }
            public static void CheckIfLookStyleIs(string style)
            {
                string checkStyle = "";
                if (WebdriverBaseClass.IsMobile)
                {

                    for (int i = 1; i < 5; i++)
                    {
                        checkStyle = driverExt.GetText(By.CssSelector(".user>.information>div>.title"));
                        if (checkStyle != "")
                        {
                            break;
                        }
                    }
                }
                else
                {
                    checkStyle = driverExt.GetText(By.CssSelector(".look-title"));
                }
                Console.WriteLine("filtered look style is: " + checkStyle);
                if (checkStyle.Contains(style))
                {
                    Console.WriteLine("Style correct, filtering works OK");
                }
                else
                {
                    Assert.Fail("Wrong style - look not filtered properly");
                }
            }
            public static void CheckIfLookStoreIs(string myStore)
            {
                string lookStore;
                if (WebdriverBaseClass.IsMobile)
                {
                    lookStore = driverExt.GetText(By.CssSelector(".store-name")).Split('-')[0].Trim();
                }
                else
                {
                    lookStore = driverExt.GetText(By.CssSelector("#link-look-store")).Split('-')[0].Trim();
                }
                Console.WriteLine("Look store is: " + lookStore);
                if (lookStore.Contains(myStore))
                {
                    Console.WriteLine("My store looks OK");
                }
                else
                {
                    Assert.Fail("Look not from user store");
                }
            }
            public static void LookWasReported()
            {
                if (WebdriverBaseClass.IsMobile)
                {
                    driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                    Assert.IsTrue(driverExt.GetText(By.CssSelector(".report-result>.text")).Contains("Thank you for flagging an issue with this look"));
                }
                else
                {
                    Assert.IsTrue(driverExt.GetText(By.Id("report-link")).Contains("You have reported this look."));
                    Assert.IsTrue(driverExt.ElementDisplayed(By.Id("report-form")));
                }

            }
            public static void LookWasOpened()
            {
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("primania/look"));
            }
            public static void LookWasClosed()
            {
                Assert.IsTrue(driverExt.GetUrl().Equals(AppUrl + "en/primania"));
            }
            public static void LookUploadPageWasOpened()
            {
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("primania/add-look"));
            }
            public static void PrimarksWereGiven()
            {
                if (driverExt.GetText(By.CssSelector(".text>strong")).Contains("MARKED!"))
                {
                    Console.WriteLine("Primarks given");
                }
                else
                {
                    Assert.Fail("Look was not primarked");
                }
            }
            public static void PrimarksWereRemoved()
            {
                if (driverExt.GetText(By.CssSelector(".text>strong")).Contains("MARKS"))
                {
                    Console.WriteLine("Primarks removed");
                }
                else
                {
                    Assert.Fail("Look was not primarked");
                }
            }
            public static void LookIdIs(string lookId)
            {
                if (driverExt.GetUrl().Contains(lookId))
                {
                    Console.WriteLine("opened look has the correct ID");
                }
                else
                {
                    Assert.Fail("Look does not have the correct ID");
                }
            }

        }
        public class ProfileAssertions : Assertions
        {
            public static void LooksCountIncreasedByOneComparedTo(int looksCountBefore)
            {
                int newLooksCount = Context.ProfilePage.GetMyLooksCount();
                if (newLooksCount == looksCountBefore + 1)
                {
                    Console.WriteLine("Number of my looks OK: increased by 1");
                }
                else
                {
                    Assert.Fail("Number of my looks is wrong");
                }
            }
            public static void LooksCountDecreasedByOneComparedTo(int looksCountBefore)
            {
                int newLooksCount = Context.ProfilePage.GetMyLooksCount();
                if (newLooksCount == looksCountBefore - 1)
                {
                    Console.WriteLine("Number of my looks OK: decreased by 1");
                }
                else
                {
                    Assert.Fail("Number of my looks is wrong");
                }
            }
            public static void PrimarkedLooksCountIncreasedByOneComparedTo(int primarkedLooksCountBefore)
            {
                int newPrimarkedLooksCount = Context.ProfilePage.GetPrimarkedLooksCount();
                if (newPrimarkedLooksCount == primarkedLooksCountBefore + 1)
                {
                    Console.WriteLine("Number of primarked looks OK: increased by 1");
                }
                else
                {
                    Assert.Fail("Number primarked my looks is wrong");
                }
            }
            public static void UserNameIs(string name)
            {
                Assert.IsTrue(driverExt.GetText(By.CssSelector(".user-name>strong>span")).Contains(name));

            }
            public static void UserBioIs(string bio)
            {
                Assert.IsTrue(driverExt.GetText(By.CssSelector(".user-description-filled.user-description")).Contains(bio));
            }
            public static void UserBlogUrlIs(string blogUrl)
            {
                Assert.IsTrue(driverExt.GetText(By.CssSelector(".user-blog-filled.user-blog>.user-info-href")).Contains(blogUrl));
            }
            public static void FavouriteDetailsDisplayed()
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".cell>h3"), 10);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".cell>h3")));
            }
            public static void FollowingCountEqualsOne()
            {
                if (Context.ProfilePage.GetFollowingCount() != 1)
                {
                    Assert.Fail("following count != 1");
                }
            }
            public static void UserIdIs(string id)
            {
                string url = driverExt.GetUrl();
                Console.WriteLine(driverExt.GetUrl());
                Console.WriteLine(id);
                Assert.IsTrue(url.Contains(id));
            }
            public static void NumberOfFollowersIncreasedByOneInComparison(int followersBefore, int followersAfter)
            {
                if (followersAfter != followersBefore + 1)
                {
                    Assert.Fail("Number of followers not increased");
                }
            }
            public static void UserIsFollowed()
            {
                Thread.Sleep(1000);
                driverExt.WaitUntilElementIsClickable(By.Id("user-follow-button"));
                string checkFollowButtonState = driverExt.GetAttributeOf(By.Id("user-follow-button"), "value");
                Assert.IsTrue(checkFollowButtonState.Contains("Unfollow"));
            }
            public static void UserIsNotFollowed()
            {
                Thread.Sleep(1000);
                driverExt.WaitUntilElementIsClickable(By.Id("user-follow-button"));
                string checkFollowButtonState = driverExt.GetAttributeOf(By.Id("user-follow-button"), "value");
                Assert.IsTrue(checkFollowButtonState.Contains("Follow"));
            }
            public static void UserWasReported()
            {
                string reportedUser = driverExt.GetText(By.Id("user-report-button"));
                Context.Assertions.StringsAreEqual(reportedUser, "You have reported this user.");
            }
            public static void FavouritesAreHidden()
            {
                Assert.IsTrue(driverExt.ElementNotDisplayed(By.Id("link-profile-favourites")));
            }
            public static void FavouritesAreVisible()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("link-profile-favourites")));
            }
        }
        public class SignInSignUpAssertions : Assertions
        {
            public static void UserWasNotSignedIn()
            {
                string validationText = "";
                if (WebdriverBaseClass.IsMobile)
                {
                    driverExt.WaitUntilElementIsPresent(By.CssSelector(".validation-message.validation-signIn-password"));
                    validationText = driverExt.GetText(By.CssSelector(".validation-message.validation-signIn-password"));
                }
                else
                {
                    driverExt.WaitUntilElementIsPresent(By.XPath(".//*[@id='wrapper']/div/div/div/div[2]/section[2]/div[1]/div/div/form/p[3]"), 10);
                    validationText = driverExt.GetText(By.XPath(".//*[@id='wrapper']/div/div/div/div[2]/section[2]/div[1]/div/div/form/p[3]"));
                }


                Assert.AreEqual("Incorrect email or password entered", validationText);
            }
            public static void UserWasSignedIn()
            {
                if (WebdriverBaseClass.IsMobile)
                {
                    Assert.IsTrue(driverExt.ElementDisplayed(By.Id("link-userProfile")));
                }
                else
                {
                    Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".menu-primark")));
                }
            }
            public static void SignInValidationEmptyEmail()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-signIn-email")).Text;
                StringAssert.Contains("This field is required", validationText);
            }
            public static void SignInValidationEmptyPassword()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-signIn-password")).Text;
                StringAssert.Contains("This field is required", validationText);
            }
            public static void SignInValidationInvalidEmail()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-signIn-email")).Text;
                StringAssert.Contains("Please enter a valid email address.", validationText);
            }
            public static void SignUpValidationEmptyName()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-firstName")).Text;
                StringAssert.Contains("This field is required", validationText);
            }
            public static void SignUpValidationEmptyEmail()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-email")).Text;
                StringAssert.Contains("This field is required", validationText);
            }
            public static void SignUpValidationEmptyConfirmEmail()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-confirmEmail")).Text;
                StringAssert.Contains("This field is required", validationText);
            }
            public static void SignUpValidationEmptyPassword()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-password")).Text;
                StringAssert.Contains("This field is required", validationText);
            }
            public static void SignUpValidationInvalidEmail()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-email")).Text;
                StringAssert.Contains("Please enter a valid email address.", validationText);
            }
            public static void SignUpValidationInvalidConfirmEmail()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-confirmEmail")).Text;
                StringAssert.Contains("Please enter a valid email address.", validationText);
            }
            public static void SignUpValidationPasswordTooShort()
            {
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-password")).Text;
                StringAssert.Contains("Your password must be at least 6 characters long", validationText);
            }
            public static void SignUpValidationEmailsDontMatch()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message.validation-singUp-confirmEmail")).Text;
                StringAssert.Contains("Email addresses don't match. Try again.", validationText);
            }
            public static void ActivateAccountMessageIsPresent()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("user-email-activate-info")));
            }
            public static void ActivateAccountMessageIsNotPresent()
            {
                Assert.IsFalse(driverExt.ElementDisplayed(By.Id("user-email-activate-info")));
            }
        }
        public class HeaderAssertions : Assertions
        {
            public static void FavouritesCountEqualsOne()
            {
                int numberOfFavorites = Context.Header.FavouritesCount();
                if (numberOfFavorites != 1)
                {
                    Assert.Fail("Number of favourites != 1");
                }
            }
            public static void FavouritesCountEqualsZero()
            {
                int numberOfFavorites = Context.Header.FavouritesCount();
                if (numberOfFavorites != 0)
                {
                    Assert.Fail("Number of favourites != 0");
                }
            }
            public static void FavouritesCountEquals(int favCount)
            {
                int numberOfFavorites = Context.Header.FavouritesCount();
                if (numberOfFavorites != favCount)
                {
                    Assert.Fail("Number of favourites != 0");
                }
            }
            public static void SocialLinksFBWasOpened()
            {
                driverExt.SwitchToLatestWindow();
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("facebook"));
                driverExt.ReturnToFirstWindow();
            }
            public static void SocialLinksTwitterWasOpened()
            {
                driverExt.SwitchToLatestWindow();
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("twitter"));
                driverExt.ReturnToFirstWindow();
            }
            public static void SocialLinksPinterestWasOpened()
            {
                driverExt.SwitchToLatestWindow();
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("pinterest"));
                driverExt.ReturnToFirstWindow();
            }
            public static void SocialLinksInstagramWasOpened()
            {
                driverExt.SwitchToLatestWindow();
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("instagram"));
                driverExt.ReturnToFirstWindow();
            }
            public static void SocialLinksGooglePlusWasOpened()
            {
                driverExt.SwitchToLatestWindow();
                string url = driverExt.GetUrl();
                Assert.IsTrue(url.Contains("plus.google"));
                driverExt.ReturnToFirstWindow();
            }
        }
        public class OurStoresAssertions : Assertions
        {
            public static void NearestStoreDistance()
            {
                var storeBoxList = driverExt.ListElements(By.CssSelector(".store-box"));

                //var storeBoxList = driver.FindElement(By.Id("stores")).FindElements(By.CssSelector(".store-box"));
                List<int> distanceList = new List<int>();
                foreach (var store in storeBoxList)
                {
                    try
                    {

                        int temp = Int16.Parse(store.FindElement(By.CssSelector(".store-box-distance")).Text.Split(' ').ElementAt(0));
                        Console.WriteLine(temp);
                        distanceList.Add(temp);
                    }
                    catch
                    {
                    }
                }
                int i = 0;
                foreach (var distance in distanceList)
                {

                    if (i == 0)
                    {
                        Assert.IsTrue(distance <= distanceList[i + 1]);
                    }
                    else
                    {
                        Assert.IsTrue(distance >= distanceList[i - 1]);
                    }
                    i++;
                }
            }
            public static void StoreDetailsDisplayed()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("store-counter")));
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".opening-times-row")));
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".store-location-map>a>img")));
                if (WebdriverBaseClass.IsMobile)
                {
                    Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".store-access")));
                }
                else
                {
                    Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".store-information")));
                }
            }            
        }
        public class SearchAssertions : Assertions
        {
            public static void SomethingWasFoundInDetailedResults()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                var elem = driverExt.FindFirstVisibleElement(By.CssSelector(".blue"));
                Assert.IsTrue(elem.Displayed);
            }
            public static void SomethingWasFound()
            {
                driverExt.WaitUntilElementIsPresent(By.Id("search-categorised"));
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("search-categorised")));
            }
            public static void NothingWasFound()
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".noSearchTitle"));
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".noSearchTitle")));
            }
            public static void FirstRecentSearchIs(string searchText)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".lastSearchContent>ul>li>a"));

                string recentSearchText = driverExt.GetText(By.CssSelector(".lastSearchContent>ul>li>a"));

                Assert.IsTrue(recentSearchText.Contains(searchText));
            }
        }
        public class FeaturesAssertions : Assertions
        {
            public static void FeatureWasOpened()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("features-header")));
            }
            public static void NextArrowNotDisplayed()
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".slick-track>div:nth-child(3)>.linkToFeatures.redirectURL"));
                Assert.IsFalse(driverExt.ElementDisplayed(By.CssSelector(".slick-next")));
            }
            public static void PreviousArrowNotDisplayed()
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".slick-track>div:nth-child(1)>.linkToFeatures.redirectURL"));
                Assert.IsFalse(driverExt.ElementDisplayed(By.CssSelector(".slick-prev")));
            }
            public static void FeatureIsInCategory(string category)
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("features-header")));
                string url = driverExt.GetUrl();
                string categoryToLower = category.ToLower();
                string convertedCategoryName = char.ToUpper(categoryToLower[0]) + categoryToLower.Substring(1);
                Assert.IsTrue(url.Contains(convertedCategoryName));
            }
            public static void EditorIsFollowed()
            {
                string checkFollowButtonState = driverExt.GetAttributeOf(By.Id("author-follow-button"), "value");
                Assert.IsTrue(checkFollowButtonState.Contains("Unfollow"));
            }
            public static void EditorIsUnfollowed()
            {
                string checkFollowButtonState = driverExt.GetAttributeOf(By.Id("author-follow-button"), "value");
                Assert.IsTrue(checkFollowButtonState.Contains("Follow"));
            }
            public static void MoreWasLoaded()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector("#featuresLoadContainer>div>.featureFourRowsContainer.featureFourRows-table:nth-child(2)")));
            }
        }
        public class HomepageAssertions : Assertions
        {
            public static void NextArrowNotDisplayed()
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".slick-track>div:nth-child(3)>.linkToFeatures.redirectURL"));
                Assert.IsFalse(driverExt.ElementDisplayed(By.CssSelector(".slick-next")));
            }
            public static void PreviousArrowNotDisplayed()
            {
                driverExt.WaitUntilElementIsClickable(By.CssSelector(".slick-track>div:nth-child(1)>.linkToFeatures.redirectURL"));
                Assert.IsFalse(driverExt.ElementDisplayed(By.CssSelector(".slick-prev")));
            }
            
        }

        public class FooterAssertions : Assertions
        {
            public static void CookiesInformationWasOpened()
            {
                driverExt.WaitUntilElementIsPresent(By.Id("cookie-policy"));

            }

            public static void SubscribePanelWasOpened()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                driverExt.WaitUntilElementIsPresent(By.Id("button-newsletter-subscribe"));
            }

            public static void SubscribeValidationConfirmation()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".cell.text-center>p"));
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".cell.text-center>p")).Text;
                StringAssert.Contains("You have successfully subscribed to our newsletter!", validationText);
            }

            public static void SubscribeValidationEmptyEmail()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message")).Text;
                StringAssert.Contains("This field is required", validationText);
            }

            public static void SubscribeValidationInvalidEmail()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message")).Text;
                StringAssert.Contains("Please enter a valid email address.", validationText);
            }
            public static void SubscribeValidationRegisteredEmail()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                string validationText = driverExt.FindFirstVisibleElement(By.CssSelector(".validation-message")).Text;
                StringAssert.Contains("This email address has already been registered", validationText);
            }
            
        }

        public class QuizAssertions : Assertions
        {
            public static void NextArrowIsntClickable()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector("button[class='button-quiz-arrow-next'][disabled='']")));
            }
            public static void ResultsPageDisplayed()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".slide.slide-resultPage")));
            }
            public static void SharingIconsDisplayed()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".container-socialIcons")));
            }
            public static void PreviousQuestionArrowNotDisplayed()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsFalse(driverExt.ElementDisplayed(By.CssSelector(".button-quiz-arrow-prev")));
            }
            public static void ImageAnswerSelected(int answerNumber)
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".container-answers.clearfix.count-3>.answer.answer-image:nth-child(" + answerNumber + ")>.overlay-selection>.selection")));
            }
            public static void PhraseAnswerSelected(int answerNumber)
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".answer.answer-phrase.selected")));
            }
        }

        public class OutfitAssertions : Assertions
        {
            public static void CompleteOutfitButtonInactive()
            {
                Assert.IsTrue(driverExt.ElementDisabled(By.Id("button-outfitbuilder-submit")));
            }
            public static void CompleteOutfitButtonActive()
            {
                Assert.IsFalse(driverExt.ElementDisabled(By.Id("button-outfitbuilder-submit")));
            }
            public static void ProductAddedToOutfit() //checks if the "add product to outfit" button turned blue
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".button.button-productDetails-outfitBuilder.added")));
            }
            public static void ProductNotInOutfit()
            {
                driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
                Assert.IsTrue(driverExt.ElementDisplayed(By.CssSelector(".button.button-productDetails-outfitBuilder")));
            }
            public static void NumberOfOutfitsIncreased(int oldOutfitNumber, int newOutfitNumber)
            {
                if (oldOutfitNumber >= newOutfitNumber)
                {
                    Assert.Fail("Outfit number not increased!");
                }
            }
            public static void NumberOfOutfitsDecreased(int oldOutfitNumber, int newOutfitNumber)
            {
                if (oldOutfitNumber <= newOutfitNumber)
                {
                    Assert.Fail("Outfit number not decreased!");
                }
            }
            public static void OutfitNameInChallengeIs(string outfitName)
            {
                StringsAreEqual(outfitName, driverExt.GetText(By.CssSelector(".outfitName")));
            }
            public static void TutorialDisplayed()
            {
                Assert.IsTrue(driverExt.ElementDisplayed(By.Id("panel-tutorial")));
            }
            
        }

        public static void StringsAreEqual(string string1, string string2)
        {
            Assert.AreEqual(string1, string2);
        }
        public static void StringsAreNotEqual(string string1, string string2)
        {
            Assert.AreNotEqual(string1, string2);
        }
        public static void ProductsPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("products"));
        }
        public static void PrimaniaPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("primania"));
        }
        public static void HomepageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("homepage"));
        }
        public static void FeaturesPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("features"));
        }
        public static void OurStoresPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("our-stores"));
        }
        public static void OurEthicsPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("our-ethics"));
        }
        public static void CareersPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("careers"));
        }
        public static void CustomerServicePageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("customer-service/faq"));
        }

        public static void TermsOfUsePageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("terms"));
        }

        public static void PrivaceCookiesPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Assert.IsTrue(url.Contains("privacy-and-cookies"));
        }

        public static void AboutUsPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Console.WriteLine("Url was: " + url);
            Assert.IsTrue(url.Contains("about-primark"));
        }


        public static void CommunityGuidelinesPageWasOpened()
        {
            string url = driverExt.GetUrl();
            Console.WriteLine("Url was: " + url);
            Assert.IsTrue(url.Contains("community-guidelines"));
        }

       


        public class MicrositeAssertions : Assertions
        {
            public static void ThreeColumnModuleDisplayed()
            {
                var threeColumnModuleList = driverExt.ListElements(By.CssSelector(".x3-module"));
                Console.WriteLine("Three column module count: " + threeColumnModuleList.Count);
                Assert.IsTrue(threeColumnModuleList.Count >= 1);
                var tempThreeColModule = threeColumnModuleList.First();
                var imgSrc = driverExt.GetAttributeOf(tempThreeColModule, By.CssSelector(".x3-item-left > img"), "src");
                Assert.IsTrue(imgSrc != "");
                imgSrc = driverExt.GetAttributeOf(tempThreeColModule, By.CssSelector(".x3-item-right.x3-block-to-hide > img"), "src");
                Assert.IsTrue(imgSrc != "");
                imgSrc = driverExt.GetAttributeOf(tempThreeColModule, By.CssSelector(".x3-item-center > img"), "src");
                Assert.IsTrue(imgSrc != "");
                var tempText = driverExt.GetText(tempThreeColModule, By.CssSelector(".small-head"));
                Assert.IsTrue(tempText != "");
                tempText = driverExt.GetText(tempThreeColModule, By.CssSelector(".big-head"));
                Assert.IsTrue(tempText != "");
                tempText = driverExt.GetText(tempThreeColModule, By.CssSelector(".x3-paragraph"));
                Assert.IsTrue(tempText != "");
            }

            public static void ImageCarouselWithTextDisplayed()
            {
                var imageCarouselList = driverExt.ListElements(By.CssSelector(".image-slider-module"));
                Console.WriteLine("Image carousels with text count: " + imageCarouselList.Count);
                Assert.IsTrue(imageCarouselList.Count >= 1);
                var imgSrc = driverExt.GetAttributeOf(imageCarouselList.First(), By.CssSelector(".slick-active > img"), "src");
                Assert.IsTrue(imgSrc != "");
            }
            public static void ImageCarouselWithTextNextArrow()
            {
                var imageCarousel = driverExt.ListElements(By.CssSelector(".image-slider-module")).First();
                var oldIndex = driverExt.GetAttributeOf(imageCarousel, By.CssSelector(".slick-active"), "index");
                MicrositePage.ImageCarouselWithTextNextArrowClick();
                var newIndex = driverExt.GetAttributeOf(imageCarousel, By.CssSelector(".slick-active"), "index");
                Assert.IsTrue(oldIndex != newIndex);
            }
            public static void ImageCarouselWithTextPreviousArrow()
            {
                var imageCarousel = driverExt.ListElements(By.CssSelector(".image-slider-module")).First();
                var oldIndex = driverExt.GetAttributeOf(imageCarousel, By.CssSelector(".slick-active"), "index");
                MicrositePage.ImageCarouselWithTextPreviousArrowClick();
                var newIndex = driverExt.GetAttributeOf(imageCarousel, By.CssSelector(".slick-active"), "index");
                Assert.IsTrue(oldIndex != newIndex);
            }

            public static void ProductsBlockDisplayed()
            {
                var productsBlockList = driverExt.ListElements(By.CssSelector(".products-block"));
                Console.WriteLine("Products blocks count: " + productsBlockList.Count);
                Assert.IsTrue(productsBlockList.Count >= 1);
                var productsList = productsBlockList.First().FindElements(By.CssSelector(".product-block"));
                Console.WriteLine("Products count: " + productsList.Count);
                Assert.IsTrue(productsList.Count >= 1);
                Assert.IsTrue(productsList.Count <= 8);
            }

            public static void ProductsCarouselDisplayed()
            {
                var productsCarouselList = driverExt.ListElements(By.CssSelector(".product-carousel-module"));
                Console.WriteLine("Products blocks count: " + productsCarouselList.Count);
                Assert.IsTrue(productsCarouselList.Count >= 1);
                var productsList = productsCarouselList.First().FindElements(By.CssSelector(".product-box-content"));
                Console.WriteLine("Products count: " + productsList.Count);
                Assert.IsTrue(productsList.Count >= 5);
                Assert.IsTrue(productsList.Count <= 15);
            }
            public static void ProductsCarouselNextArrow()
            {
                var productCarousel = driverExt.ListElements(By.CssSelector(".product-carousel-module")).First();
                List<string> oldIndexList = new List<string>();
                var tempList = driverExt.ListElements(productCarousel, By.CssSelector(".slick-active"));
                foreach (var product in tempList)
                {
                    oldIndexList.Add(product.GetAttribute("index"));
                }
                MicrositePage.ProductCarouselNextArrowClick();
                List<string> newIndexList = new List<string>();
                tempList = driverExt.ListElements(productCarousel, By.CssSelector(".slick-active"));
                foreach (var product in tempList)
                {
                    newIndexList.Add(product.GetAttribute("index"));
                }
                Assert.IsTrue(oldIndexList.Except(newIndexList).Count() >= 1);
            }

            public static void ProductsCarouselPreviousArrow()
            {
                var productCarousel = driverExt.ListElements(By.CssSelector(".product-carousel-module")).First();
                List<string> oldIndexList = new List<string>();
                var tempList = driverExt.ListElements(productCarousel, By.CssSelector(".slick-active"));
                foreach (var product in tempList)
                {
                    oldIndexList.Add(product.GetAttribute("index"));
                }
                MicrositePage.ProductCarouselPreviousArrowClick();
                List<string> newIndexList = new List<string>();
                tempList = driverExt.ListElements(productCarousel, By.CssSelector(".slick-active"));
                foreach (var product in tempList)
                {
                    newIndexList.Add(product.GetAttribute("index"));
                }
                Assert.IsTrue(oldIndexList.Except(newIndexList).Count() >= 1);
            }

            public static void HeroModuleTypeOneDisplayed()
            {
                var heroModuleTypeOneList = driverExt.ListElements(By.CssSelector(".hero-module-type-one"));
                Console.WriteLine("Hero module type one count: " + heroModuleTypeOneList.Count);
                Assert.IsTrue(heroModuleTypeOneList.Count >= 1);
            }

            public static void HeroModuleTypeTwoDisplayed()
            {
                var heroModuleTypeOneList = driverExt.ListElements(By.CssSelector(".hero-module"));
                Console.WriteLine("Hero module type two count: " + heroModuleTypeOneList.Count);
                Assert.IsTrue(heroModuleTypeOneList.Count >= 1);
            }

            public static void TextModuleDisplayed()
            {
                var heroModuleTypeOneList = driverExt.ListElements(By.CssSelector(".text-module"));
                Console.WriteLine("Text module count: " + heroModuleTypeOneList.Count);
                Assert.IsTrue(heroModuleTypeOneList.Count >= 1);
            }

            public static void NavigationMenuDisplayed()
            {
                var navLinkList = driverExt.ListElements(By.CssSelector(".nav-main > ul > li > a"));
                Console.WriteLine("Navigation link count: " + navLinkList.Count);
                Assert.True(navLinkList.Count >= 1);
                Assert.True(navLinkList.Count <= 3);
                var goToPrimarkLink = driverExt.GetAttributeOf(By.CssSelector(".go-to-primark > a"), "href");
                driverExt.ClickCss(".go-to-primark > a");
                var pageUrl = driverExt.GetUrl();
                StringAssert.Contains(WebdriverBaseClass.AppUrl, pageUrl);
                StringAssert.Contains(goToPrimarkLink, pageUrl);
            }

            public static void ImageCarouselDisplayed()
            {
                var imageCarouselsList = driverExt.ListElements(By.CssSelector(".carousel-module"));
                Console.WriteLine("Image carousel count: " + imageCarouselsList.Count);
                Assert.True(imageCarouselsList.Count >= 1);
            }

            public static void ImageCarouselNextArrow()
            {
                var imageCarousel = driverExt.ListElements(By.CssSelector(".carousel-module")).First();
                List<string> oldIndexList = new List<string>();
                var tempList = driverExt.ListElements(imageCarousel, By.CssSelector(".slick-active"));
                foreach (var image in tempList)
                {
                    oldIndexList.Add(image.GetAttribute("index"));
                }
                MicrositePage.ImageCarouselNextArrowClick();
                List<string> newIndexList = new List<string>();
                tempList = driverExt.ListElements(imageCarousel, By.CssSelector(".slick-active"));
                foreach (var image in tempList)
                {
                    newIndexList.Add(image.GetAttribute("index"));
                }
                Assert.IsTrue(oldIndexList.Except(newIndexList).Count() >= 1);
            }

            public static void ImageCarouselPreviousArrow()
            {
                var imageCarousel = driverExt.ListElements(By.CssSelector(".carousel-module")).First();
                List<string> oldIndexList = new List<string>();
                var tempList = driverExt.ListElements(imageCarousel, By.CssSelector(".slick-active"));
                foreach (var image in tempList)
                {
                    oldIndexList.Add(image.GetAttribute("index"));
                }
                MicrositePage.ImageCarouselPreviousArrowClick();
                List<string> newIndexList = new List<string>();
                tempList = driverExt.ListElements(imageCarousel, By.CssSelector(".slick-active"));
                foreach (var image in tempList)
                {
                    newIndexList.Add(image.GetAttribute("index"));
                }
                Assert.IsTrue(oldIndexList.Except(newIndexList).Count() >= 1);
            }

            public static void GoogleMapsDisplayed()
            {
                var mapsList = driverExt.ListElements(By.CssSelector(".map-control"));
                Console.WriteLine("Google maps count: " + mapsList.Count);
                Assert.True(mapsList.Count >= 1);
            }

            public static void VideoPlayerModuleDisplayed()
            {
                var videoPlayerModuleList = driverExt.ListElements(By.CssSelector(".player-module"));
                Console.WriteLine("Video player module count: " + videoPlayerModuleList.Count);
                Assert.True(videoPlayerModuleList.Count >= 1);
                var videoPlayer = videoPlayerModuleList.First();
                Assert.IsTrue(videoPlayer.FindElement(By.CssSelector(".image-placeholder")).Displayed);
                driverExt.Click(videoPlayer, By.CssSelector(".videoCtaButton-play"));
                driverExt.SwitchToIframe(By.Id("video0"));
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".playing-mode"));
                driverExt.SwitchToDefaultContent();
                Assert.IsFalse(videoPlayer.FindElement(By.CssSelector(".image-placeholder")).Displayed);
            }

            public static void IframeModuleDisplayed()
            {
                var iframeModuleList = driverExt.ListElements(By.CssSelector(".iframe-module"));
                Console.WriteLine("Iframe module count: " + iframeModuleList.Count);
                Assert.True(iframeModuleList.Count >= 1);
            }

            
        }
    }
}
