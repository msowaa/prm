﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class Homepage
    {
        public static void ViewFirstTopCarouselItem(bool click = false)
        {
            driverExt.ClickCss(".slick-dots>li:nth-child(1)>.page-button");
            if (click)
            {
                driverExt.ClickCss(".slick-track>div:nth-child(1)>.linkToFeatures.redirectURL");
            }
        }
        public static void ViewSecondTopCarouselItem(bool click = false)
        {
            driverExt.ClickCss(".slick-dots>li:nth-child(2)>.page-button");
            if (click)
            {
                driverExt.ClickCss(".slick-track>div:nth-child(2)>.linkToFeatures.redirectURL");
            }
        }
        public static void ViewThirdTopCarouselItem(bool click = false)
        {
            driverExt.ClickCss(".slick-dots>li:nth-child(3)>.page-button");
            if (click)
            {
                driverExt.ClickCss(".slick-track>div:nth-child(3)>.linkToFeatures.redirectURL");
            }
        }
        public static void ClickNextTopCarouselItem()
        {
            driverExt.ClickCss(".slick-next");
        }
        public static void ClickPreviousTopCarouselItem()
        {
            driverExt.ClickCss(".slick-prev");
        }
        public static void OpenFirstCTA2To2()
        {
            driverExt.ClickCss(".imageCta2To2>.boxArea.boxNumber-0>a");
        }
        public static void OpenFirstImageCTA()
        {
            driverExt.ClickCss(".imageCta-descriptionBox>.table>.cell>.box-ctaButton.homePage-button.redirectURL");
        }
        public static void OpenSocialLinksFeature()
        {
            driverExt.ClickCss(".box-ctaButton.feature-button.redirectURL");
        }
        public static void OpenSocialLinksFB()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".icon-facebook");
            }
            else
            {
                driverExt.ClickId("facebook-link");
            }
        }
        public static void OpenSocialLinksTwitter()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".icon-twitter-bird");
            }
            else
            {
                driverExt.ClickId("twitter-link");
            }
        }
        public static void OpenSocialLinksPinterest()
        {
            if(WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".icon-pinterest");
            }
            else
            {
                driverExt.ClickId("pinterest-link");
            }
        }
        public static void OpenSocialLinksInstagram()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".icon-instagram");
            }
            else
            {
                driverExt.ClickId("instagram-link");
            }
        }
        public static void OpenSocialLinksGooglePlus()
        {
            if(WebdriverBaseClass.IsMobile)
            {
                driverExt.ClickCss(".icon-gplus");
            }
            else
            {
                driverExt.ClickId("gplus-link");
            }
        }
        public static void OpenFeatureRowFirstFeature()
        {
            driverExt.ClickCss(".featureThreeRowsContainer.featureRows-table>.featureRow.featureRow-column-cell.firstFeature>.buttonBox.firstFeature>.box-ctaButton.feature-button.redirectURL");
        }
        public static void PrimaniaCarouselClickNextArrow()
        {
            driverExt.ClickCss("#primania-carousel-navigation-PrimaniaCarouselRow>.slick-next");
        }
        public static void PrimaniaCarouselClickPreviousArrow()
        {
            driverExt.ClickCss("#primania-carousel-navigation-PrimaniaCarouselRow>.slick-prev");
        }
        public static void PrimaniaCarouselOpenLook()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".primania-box-content.slick-slide.slick-active>.image>a"));
        }
        public static void PrimaniaCarouselUploadLook()
        {
            driverExt.ClickCss(".primania-box-content.first-box.slick-slide.slick-active>a");
        }
        public static void PrimaniaCarouselBrowsePrimania()
        {
            driverExt.ClickCss("#PrimaniaCarouselRow>.primania-carousel-cta-button.homePage-button");
        }
        public static void ProductsCarouselClickNextArrow()
        {
            driverExt.ClickCss("#product-carousel-navigation-ProductsRow2>.slick-next");
        }
        public static void ProductsCarouselClickPreviousArrow()
        {
            driverExt.ClickCss("#product-carousel-navigation-ProductsRow2>.slick-prev");
        }
        public static void ProductsCarouselFavouriteItem()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".image-carousel-item.right.slick-slide.slick-active"));
            //driverExt.ClickXpath(".//*[@id='product-slick-carousel-ProductsRow2']/div/div/div[4]/div/div/div[2]/button");
            driverExt.ClickFirstVisibleElement(By.CssSelector(".button.button-favourite"));
        }
        public static void ProductsCarouselOpenProductDetails()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".product-box-content.slick-slide.slick-active>.box-square>.box-container.table>.image.cell>a>img"));
        }
    }
}
