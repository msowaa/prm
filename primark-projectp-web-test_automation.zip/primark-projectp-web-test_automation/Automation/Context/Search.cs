﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    public class Search
    {
        public static void CloseSearchOverlay()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector("#search>.search-searchArea>.search-close-button.clear"));
            driverExt.ClickCss("#search>.search-searchArea>.search-close-button.clear");
        }
        public static void SearchButtonClick()
        {
            driverExt.ClickId("search-form-button");
        }
        public static void FillSearchFieldWith(string searchText, bool pressEnter = false)
        {
            driverExt.FillTextField(By.Id("search-input-text"), searchText);            
            
            if (pressEnter)
            {
                driverExt.FillTextField(By.Id("search-input-text"), Keys.Return);
            }
        }
        public static void SelectFirstSuggestion()
        {
            driverExt.WaitForAjax(WebdriverBaseClass.ajaxTimeout);
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".suggestivSearchContent>ul"));
            driverExt.ClickCss(".suggestivSearchContent>ul>li:nth-child(2)>a");
        }
        public static void SelectFirstRecentSearch()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".lastSearchContent>ul>li>a"));
            driverExt.ClickCss(".lastSearchContent>ul>li>a");
        }
        public static void ViewAllProductsFound()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".search-products-categorized>.categoryOfProducts>.search-productBox.last-box>div.square>a.redirectLink"));
                driverExt.ClickCss(".search-products-categorized>.categoryOfProducts>.search-productBox.last-box>div.square>a.redirectLink");
            }
            else
            {
                driverExt.ClickCss(".search-productBox.last-box div.square a.redirectLink");
            }
        }
        public static void ViewFirstFoundProductDeeplink()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                if (driverExt.GetUrl().Contains("search/search-products-results"))
                {
                    driverExt.WaitUntilElementIsPresent(By.CssSelector(".results-content>.search-productBox.cell>.square>.redirectLink"));
                    driverExt.ClickCss(".results-content>.search-productBox.cell>.square>.redirectLink");
                }
                else
                {
                    driverExt.WaitUntilElementIsPresent(By.CssSelector(".search-productBox.cell>.square>.redirectLink"));
                    driverExt.ClickCss(".search-productBox.cell>.square>.redirectLink");
                }
            }
            else
            {
                driverExt.ClickFirstVisibleElement(By.CssSelector(".redirectLink"));
            }
        }
        public static void ViewAllFeaturesFound()
        {
            driverExt.ClickCss(".featuresFoundSizeTitle>a");
        }
        public static void ViewFirstFoundFeature()
        {
            if (WebdriverBaseClass.IsMobile)
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".featureRow.cell.feature-1>.buttonBox.feature-1>.box-ctaButton.feature-button"));
                driverExt.ClickCss(".featureRow.cell.feature-1>.buttonBox.feature-1>.box-ctaButton.feature-button");
            }
            else
            {
                driverExt.WaitUntilElementIsPresent(By.CssSelector(".buttonBox.feature-1"));
                driverExt.ClickFirstVisibleElement(By.CssSelector("#searchFeaturesContainer>div>.featureFourRowsContainer.featureFourRows-table>.cell>.featureTwoRows-table>.featureRow.cell.feature-1>.buttonBox.feature-1"));
            }
        }
        public static void ViewFirstFeatureInFearureSearchResults()
        {
            driverExt.ClickFirstVisibleElement(By.CssSelector(".box-ctaButton.feature-button"));
        }
        public static void ViewStores()
        {
            driverExt.ClickCss("div.cell.box-2 div.box-background div.osCarrers-box p a span");
        }
        public static void ViewCareers()
        {
            driverExt.ClickCss("div.cell.box-1 div.box-background div.osCarrers-box p a span");            
        }
        public static void NoResultsTryAgain()
        {
            driverExt.WaitUntilElementIsPresent(By.CssSelector(".noResults-buttons.anotherTry"));
            driverExt.ClickCss(".noResults-buttons.anotherTry");
        }
        public static void NoResultsBrowseProducts()
        {
            driverExt.WaitUntilElementIsPresent(By.Id("noResults-goProducts-link"));
            driverExt.ClickId("noResults-goProducts-link");
        }
        public static void ProductSearchResultsFilterLatest()
        {
            driverExt.ClickId("Latest");
        }
        public static void ProductSearchResultrFilterLowestPrice()
        {
            driverExt.ClickId("PriceFromLowest");
        }
        public static void ProductSearchResultsFilterHighestPrice()
        {
            driverExt.ClickId("PriceFromHighest");
        }
        public static void BackToSearch()
        {
            driverExt.ClickId("navigation-return");
        }
    }
}
