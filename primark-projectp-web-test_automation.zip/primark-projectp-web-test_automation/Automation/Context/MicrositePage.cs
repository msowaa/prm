﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace Automation.Context
{
    class MicrositePage
    {
        public static void GoToMicrosite()
        {
            string url = WebdriverBaseClass.AppUrl + "en/micross";
            if (!driverExt.GetUrl().Contains(url))
            {
                driverExt.OpenUrl(url);
            }
        }

        public static void ImageCarouselWithTextNextArrowClick()
        {
            driverExt.ClickCss(".image-slider-right-arrow");
        }
        public static void ImageCarouselWithTextPreviousArrowClick()
        {
            driverExt.ClickCss(".image-slider-left-arrow");
        }

        public static void ProductCarouselNextArrowClick()
        {
            driverExt.ClickCss(".product-carousel-navigation > .slick-next");
        }
        public static void ProductCarouselPreviousArrowClick()
        {
            driverExt.ClickCss(".product-carousel-navigation > .slick-prev");
        }

        public static void ImageCarouselNextArrowClick()
        {
            driverExt.ClickCss(".carousel-navigation > .slick-next");
        }
        public static void ImageCarouselPreviousArrowClick()
        {
            driverExt.ClickCss(".carousel-navigation > .slick-prev");
        }
    }
}
