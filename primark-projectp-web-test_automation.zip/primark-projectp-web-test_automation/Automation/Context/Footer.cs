﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
//using Automation.TestsDesktop;
using System.Threading;


namespace Automation.Context
{
    public class Footer
    {

        public static void OpenCustomerService()
        {
            driverExt.ClickCss(".cell>ul>li:nth-child(1)>a");
        }

        public static void OpenTermsOfUse()
        {
            driverExt.ClickCss(".cell>ul>li:nth-child(2)>a");
        }

        public static void OpenPrivacyCookies()
        {
            driverExt.ClickCss(".cell>ul>li:nth-child(3)>a");
        }

        public static void OpenCommunityGuidelines()
        {
            driverExt.ClickCss(".cell>ul>li:nth-child(4)>a");
        }

        public static void OpenAboutUs()
        {
            driverExt.ClickCss(".cell>ul>li:nth-child(5)>a");
        }

        public static void CloseCookiesInformation()
        {

            driverExt.ClickXpath("/html/body/div[4]/div/div[2]");
        }

        public static void OpenSubscribePanel()
        {
            driverExt.ClickId("button-subscribe-to-newsletter");
        }

        public static void ClickSubscribe()
        {
            driverExt.ClickId("button-newsletter-subscribe");
        }

        public static void FillEmailFieldWith(string email)
        {
            driverExt.FindFirstVisibleElement(By.XPath("//*[@id='section-newsletter']/div[1]/div/div[1]/form/div/div/input")).SendKeys(email);

        }

        public static void FillEmailFieldWith(string email, bool clear)
        {
            if (clear)
            {
                driverExt.FindFirstVisibleElement(By.XPath("//*[@id='section-newsletter']/div[1]/div/div[1]/form/div/div/input")).Clear();
            }
            driverExt.FindFirstVisibleElement(By.XPath("//*[@id='section-newsletter']/div[1]/div/div[1]/form/div/div/input")).SendKeys(email);

        }

    }
}
