﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using Automation.Context;


namespace Automation.TestsMobile
{
    class M002_MyProfile : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_MyLooksInProfile()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string path;
            if (WebdriverBaseClass.IsMobile)
            {
                path = "//storage//emulated//0//testdata//testLook.jpg";
            }
            else
            {
                path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg";
            }

            string itemName = Helpers.GetSalt();
            string itemPrice = "10";
            string description = "test desc " + Helpers.GetSalt();

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            ProfilePage.ViewLooksTab();
            int numberOfMyLooks = ProfilePage.GetMyLooksCount();
            string newlookId = Helpers.AddLookToPrimaniaViaMyProfile(path, itemName, itemPrice, description);
            Header.ViewProfile();
            ProfilePage.ViewLooksTab();
            Assertions.ProfileAssertions.LooksCountIncreasedByOneComparedTo(numberOfMyLooks);
            ProfilePage.OpenFirstLook();
            Assertions.PrimaniaAssertions.LookIdIs(newlookId);
            Header.ViewProfile();
            ProfilePage.ViewLooksTab();
            numberOfMyLooks = ProfilePage.GetMyLooksCount();
            ProfilePage.RemoveLook();
            ProfilePage.WaitUntilLooksCounterUpdates();
            Assertions.ProfileAssertions.LooksCountDecreasedByOneComparedTo(numberOfMyLooks);
        }

        [Test]
        public void P002_MyPrimarkedLooksInProfile()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            ProfilePage.ViewLooksTab();
            int PrimarkedLooksCount = ProfilePage.GetPrimarkedLooksCount();
            Header.OpenPrimania();
            PrimaniaPage.OpenFirstLook();
            PrimaniaPage.FindLookWithoutPrimarks();
            PrimaniaPage.GivePrimarks();
            PrimaniaPage.CloseLook();
            Header.ViewProfile();
            ProfilePage.ViewLooksTab();
            Assertions.ProfileAssertions.PrimarkedLooksCountIncreasedByOneComparedTo(PrimarkedLooksCount);
        }

        [Test]
        public void P003_LooksFromMyStore()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string path;
            if (WebdriverBaseClass.IsMobile)
            {
                path = "//storage//emulated//0//testdata//testLook.jpg";
            }
            else
            {
                path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg";
            }
            Helpers.SignIn(driver, email, password, false);
            string lookID = Helpers.AddLookToPrimania(driver, path, "name", "5", "test desc " + Helpers.GetSalt());
            Header.ViewProfile();
            string userStore = ProfilePage.GetUserStore();
            ProfilePage.ViewLooksTab();
            ProfilePage.ViewLooksFromMyStore();
            ProfilePage.OpenFirstLookFromMyStore();
            Assertions.PrimaniaAssertions.CheckIfLookStoreIs(userStore);
        }

        [Test]
        public void P004_EditProfileDetails()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            string name = "name" + Helpers.GetSalt();
            string surname = "surname" + Helpers.GetSalt();
            string bio = "bio " + Helpers.GetSalt();
            string phone = Helpers.GetSaltWithout_Char();
            string blogUrl = "http://www." + Helpers.GetSalt() + ".com";


            Helpers.SignIn(driver, email, password, false);
            Header.EditProfile();
            ProfilePage.ChangeUserNameTo(name);
            ProfilePage.ChangeUserSurnameTo(surname);
            ProfilePage.ChangeUserBioTo(bio);
            ProfilePage.ChangeUserPhoneNumberTo(phone);
            ProfilePage.ChangeUserBlogUrlTo(blogUrl);
            ProfilePage.ChangeUserCountry();

            ProfilePage.SaveSettings();
            if (WebdriverBaseClass.IsMobile)
            {
                Header.ViewProfile();
            }
            Assertions.ProfileAssertions.UserNameIs(name);
            Assertions.ProfileAssertions.UserBioIs(bio);
            Assertions.ProfileAssertions.UserBlogUrlIs(blogUrl);

            ProfilePage.OpenUserBlog();
        }

        [Test]
        public void P005_UploadUserPhoto()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string path;
            if (WebdriverBaseClass.IsMobile)
            {
                path = "//storage//emulated//0//testdata//avatar.png";
            }
            else
            {
                path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\avatar.png";
            }
            Helpers.SignIn(driver, email, password, false);

            Header.EditProfile();
            ProfilePage.ChangePhoto(path);
            ProfilePage.SaveSettings();

        }

        [Test]
        public void P011_ChangePassword()
        {
            string email = Users.PasswordChangeUser.Email;
            string password = Users.PasswordChangeUser.Password;
            string newPassword = "asdfgh";

            Helpers.SignIn(driver, email, password, false);
            Header.EditProfile();
            ProfilePage.ChangePassword(password, newPassword);
            ProfilePage.SaveSettings();
            Header.SignOut();

            Helpers.SignIn(driver, email, newPassword, false);      //switch back to old password
            Header.EditProfile();
            ProfilePage.ChangePassword(newPassword, password);
            ProfilePage.SaveSettings();
        }

        [Test]
        public void P006_ChangeMyStore()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            if (WebdriverBaseClass.IsMobile)
            {
                Header.ViewProfile();
            }
            else
            {
                Header.EditProfile();
            }
            string currentStore = ProfilePage.GetUserStore();
            if (WebdriverBaseClass.IsMobile)
            {
                Header.EditProfile();
            }
            Helpers.ChangeStoreToRandom(currentStore);
            ProfilePage.SaveSettings();
            if (WebdriverBaseClass.IsMobile)
            {
                Header.ViewProfile();
            }
            string changedStore = ProfilePage.GetUserStore();
            Assertions.StringsAreNotEqual(currentStore, changedStore);
        }

        [Test]
        public void P012_ConnectDisconnectFB()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string fblogin = Users.SocialServicesUser001.Email;
            string fbPassword = Users.SocialServicesUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.EditProfile();
            ProfilePage.ToggleConnectFbAccount();
            Helpers.LogInToFB(fblogin, fbPassword);
            Header.SignOut();
            Helpers.SignInViaFbWhenLoggedInToFb();
            Header.EditProfile();
            ProfilePage.ToggleConnectFbAccount();
            ProfilePage.SetPasswordAfterFbDisconnect(password);
            ProfilePage.SaveSettings();
            Header.SignOut();
            Helpers.SignIn(driver, email, password, false);     //verify, that fb was disconnected
            Assertions.SignInSignUpAssertions.UserWasSignedIn();
        }

        [Test]
        public void P007_DeleteAccount()
        {
            string email = Helpers.CreateUserNoSitecore();
            string password = "qwerty";
                 

            Helpers.SignIn(driver, email, password, false);
            Header.EditProfile();
            ProfilePage.DeleteProfile();
            ProfilePage.DeleteProfileConfirm();
            Header.SignIn();
            //SignInSignUpPage.ChooseSignIn();
            SignInSignUpPage.FillEmailSignInFieldWith(email);
            SignInSignUpPage.FillPasswordSignInFieldWith(password);
            SignInSignUpPage.ClickSignIn();
            Assertions.SignInSignUpAssertions.UserWasNotSignedIn();
        }

        [Test]
        public void P008_AddRemoveFavourites()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Helpers.ClearFavourites(driver);
            Header.OpenProducts();
            Header.ClickFavouritesButton();
            ProfilePage.StartHuntingForFavourites();
            ProductsPage.FavouriteFirstProduct();
            ProductsPage.ConfirmFirstFavourite();
            Assertions.HeaderAssertions.FavouritesCountEqualsOne();
            Header.ClickFavouritesButton();
            ProfilePage.ClickFirstFavourite();
            ProfilePage.ClickLetsAddMoreProducts();
            Assertions.ProductsPageWasOpened();
            Header.ClickFavouritesButton();
            ProfilePage.RemoveFirstFavouriteClickButton();
            ProfilePage.RemoveFirstFavouriteConfirm();
            Assertions.HeaderAssertions.FavouritesCountEqualsZero();
        }

        [Test]
        public void P009_FavouritesWhenNotSignedIn()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Helpers.ClearFavourites(driver);
            Header.SignOut();
            Header.OpenProducts();
            ProductsPage.FavouriteFirstProduct();
            ProductsPage.ConfirmFirstFavourite();
            Assertions.HeaderAssertions.FavouritesCountEqualsOne();
            Header.ClickFavouritesButton();
            //ProfilePage.ClickFirstFavourite();
            //Assertions.ProfileAssertions.FavouriteDetailsDisplayed();
            //ProfilePage.CloseFavourite();
            ProfilePage.ClickCookieFavouritesExpirationWarning();
            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            ProfilePage.ViewFavouritesTab();
            ProfilePage.ClickFirstFavourite();
            Assertions.ProfileAssertions.FavouriteDetailsDisplayed();
        }

        [Test]
        public void P010_FollowingFollowers()
        {
            string email = Users.PrimarkUser001.Email;
            string emailFollow = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser001.Password;
            string passwordFollow = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            string userId = ProfilePage.GetUserId();
            Helpers.ClearFollowing();
            Header.SignOut();

            Helpers.SignIn(driver, emailFollow, passwordFollow, false);

            string lookID;
            if (WebdriverBaseClass.IsMobile)
            {
                lookID = Helpers.AddLookToPrimaniaViaMyProfile("//storage//emulated//0//testdata//testLook.jpg", "name", "5", "desc");
            }
            else
            {
                lookID = Helpers.AddLookToPrimaniaViaMyProfile(Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase) + "\\Resources\\testLook.jpg", "name", "5", "desc");
            }

            Header.ViewProfile();
            Helpers.ClearFollowing();
            string followUserId = ProfilePage.GetUserId();
            ProfilePage.ViewFollowersFollowingTab();
            int numberOfFollowers = ProfilePage.GetFollowersCount();
            Header.SignOut();

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            PrimaniaPage.OpenLookWithId(lookID);
            PrimaniaPage.ClickFollow();
            Header.ViewProfile();
            ProfilePage.ViewFollowersFollowingTab();
            ProfilePage.ViewFollowing();
            int numberOfFollowing = ProfilePage.GetFollowingCount();
            Assertions.ProfileAssertions.FollowingCountEqualsOne();
            ProfilePage.ViewFirstFollowingFollower();
            ProfilePage.ViewFavouritesTab();
            Assertions.ProfileAssertions.UserIdIs(followUserId);
            Header.SignOut();

            Helpers.SignIn(driver, emailFollow, passwordFollow, false);
            Header.ViewProfile();
            ProfilePage.ViewFollowersFollowingTab();
            int numberOfFollowersAfterFollowed = ProfilePage.GetFollowersCount();
            Assertions.ProfileAssertions.NumberOfFollowersIncreasedByOneInComparison(numberOfFollowers, numberOfFollowersAfterFollowed);
            ProfilePage.ClickFollow();
            Assertions.ProfileAssertions.FollowingCountEqualsOne();
            ProfilePage.ViewFollowing();
            ProfilePage.ViewFirstFollowingFollower();
            ProfilePage.ViewFollowersFollowingTab();
            ProfilePage.ViewFollowing();

        }
        [Test]
        public void P013_FollowUserViaProfileButton()
        {
            string email = Users.PrimarkUser001.Email;
            string emailFollow = Users.PrimarkUser002.Email;
            string password = Users.PrimarkUser001.Password;
            string passwordFollow = Users.PrimarkUser002.Password;

            Helpers.SignIn(driver, emailFollow, passwordFollow, false);
            Header.ViewProfile();
            string userId = ProfilePage.GetUserId();
            Header.SignOut();
            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            Helpers.ClearFollowing();
            Helpers.OpenProfileOfUserWithId(userId);
            ProfilePage.ClickFollowUnfollowButton();
            Assertions.ProfileAssertions.UserIsFollowed();
            Helpers.Refresh();
            ProfilePage.ClickFollowUnfollowButton();
            Assertions.ProfileAssertions.UserIsNotFollowed();
        }
        [Test]
        public void P014_ReportUser()
        {
            string email = Users.PrimarkUser001.Email;
            string emailReport = Helpers.CreateUserNoSitecore();
            string password = Users.PrimarkUser001.Password;
            string passwordReport = Users.NewUser.Password;
            string reportReason = "automated test " + Helpers.GetSalt();

            Helpers.SignIn(driver, emailReport, passwordReport, false);
            Header.ViewProfile();
            string userId = ProfilePage.GetUserId();
            Header.SignOut();
            Helpers.SignIn(driver, email, password, false);
            Helpers.OpenProfileOfUserWithId(userId);
            ProfilePage.ClickReportUser();
            ProfilePage.GiveReasonForUserReport(reportReason);
            ProfilePage.SubmitUserReport();
            Assertions.ProfileAssertions.UserWasReported();
        }
        [Test]
        public void P015_FavouritesVisibility()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            string userId = ProfilePage.GetUserId();
            Header.EditProfile();
            ProfilePage.ToggleFavouritesVisibility();
            ProfilePage.SaveSettings();
            Header.SignOut();
            Helpers.OpenProfileOfUserWithId(userId);
            Assertions.ProfileAssertions.FavouritesAreHidden();
            Helpers.SignIn(driver, email, password, false);
            Header.EditProfile();
            ProfilePage.ToggleFavouritesVisibility();
            ProfilePage.SaveSettings();
            Header.SignOut();
            Helpers.OpenProfileOfUserWithId(userId);
            Assertions.ProfileAssertions.FavouritesAreVisible();
        }

    }
}
