﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using Automation.Context;


namespace Automation.TestsMobile
{
    [TestFixture]
    class M005_OurStores : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }
        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }
        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }
        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }
        
        [Test]
        public void P001_OurStoresLocateMyNearestStore()
        {
            Helpers.CloseCookiePolicy();
            Header.OpenOurStores();
            OurStoresPage.ClickLocateNearestStore();
            OurStoresPage.WaitForStoresListLoad();
            Assertions.OurStoresAssertions.NearestStoreDistance();            
        }

        [Test]
        public void P002_OurStoresStoreDetails()
        {
            Helpers.CloseCookiePolicy();
            Header.OpenOurStores();
            OurStoresPage.OpenFirstStoreDetails();
            Assertions.OurStoresAssertions.StoreDetailsDisplayed();
        }

        [Test]
        public void P003_OurStoresSetAsMyPrimark()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string storeSearchFirstLetter = Helpers.GenerateRandomLetter();

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            string currentStore = ProfilePage.GetUserStore();
            Header.OpenOurStores();
            OurStoresPage.SearchForStore(storeSearchFirstLetter);
            Helpers.OpenStoreDifferentFrom(currentStore);
            OurStoresPage.SetAsMyPrimark();
            string storeName = OurStoresPage.GetStoreName();
            Header.ViewProfile();
            string changedStore = ProfilePage.GetUserStore();
            Assertions.StringsAreNotEqual(currentStore, changedStore);     
        }

        [Test]
        public void P004_StoreProductsDisplayed()
        {
            Context.Footer.CloseCookiesInformation();
            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.OurStoresPage.OpenFirstProductInStore();
            Context.Assertions.ProductsAssertions.DeeplinkWasOpended();
            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.OurStoresPage.ClickViewLatestProductsButton();
            Context.Assertions.ProductsPageWasOpened();
        }

        [Test]
        public void P005_FavouritesInStoreDetails()
        {
            int numberOfFavourites = Context.Header.FavouritesCount();

            Context.Header.OpenOurStores();
            Context.OurStoresPage.OpenFirstStoreDetails();
            Context.OurStoresPage.FavouriteAProductInStore();
            Context.Assertions.ProductsAssertions.FirstFavouriteWasAdded();
            Context.Assertions.HeaderAssertions.FavouritesCountEquals(numberOfFavourites + 1);
            Context.Assertions.ProductsAssertions.ProductWasFavourited();
            Context.OurStoresPage.UnfavouriteAProductInStore();
            Context.Assertions.ProductsAssertions.ProductWasUnfavourited();
        }
    }
}
