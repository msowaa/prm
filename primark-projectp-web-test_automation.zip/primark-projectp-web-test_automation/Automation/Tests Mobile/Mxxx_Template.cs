﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Automation.TestsMobile
{
    //[TestFixture]
    class Mxxx_Template : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();

        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }


        //[Test]
        public void test01()
        {

        }

    }
}
