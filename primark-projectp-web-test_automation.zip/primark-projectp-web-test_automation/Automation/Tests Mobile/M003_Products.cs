﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace Automation.TestsMobile
{
    class M003_Products : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_ViewProductDetails()
        {
            Context.MobileMenu.ToggleMenu();
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.ViewFirstProductDetails();            
            Context.ProductsPage.ViewFirstProductDetails();
            Context.Assertions.ProductsAssertions.ProductDetailsExist();
            Context.ProductsPage.CloseProductDetails();
        }

        [Test]
        public void P002_OpenProductDeeplink()
        {
            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu();
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.ProductsPage.ReturnToCategoryFromDeeplink();
        }
        [Test]
        public void P003_ProductsNavigation()
        {
            Context.MobileMenu.ToggleMenu();
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.ViewFirstProductDetails();
            string firstProductName = Context.ProductsPage.GetProductName();
            Context.ProductsPage.NextProduct();
            string secondProductName = Context.ProductsPage.GetProductName();
            Assert.AreNotEqual(firstProductName, secondProductName);
            Context.ProductsPage.PreviousProduct();
            secondProductName = Context.ProductsPage.GetProductName();
            Assert.AreEqual(firstProductName, secondProductName);

        }
        [Test]
        public void P004_ShareProductOnFB()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu();            
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnFB(driver, email, password, description);
        }

        [Test]
        public void P005_ShareProductOnTwitter()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnTwitter(driver, email, password, description);
        }

        [Test]
        public void P006_ShareOnPinterest()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnPinterest(driver, email, password);
        }

        [Test]
        public void P007_ShareOnTumblr()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnTumblr(driver, email, password, description);
        }
        [Test]
        public void P008_ShareOnGooglePlus()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSaltWithout_Char();

            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Helpers.ShareOnGPlus(email, password, description);
        }

        [Test]
        public void P009_CategoryMenu()
        {
            string category = "men";
            string subcategory = "jeans";

            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory(category);    //new arrivals                         
            Context.MobileMenu.OpenProductSubcategory(category, subcategory);
            Context.Assertions.ProductsAssertions.CheckIfCategoryNameIs(subcategory);
        }

        [Test]
        public void P010_ProductFilters()
        {
            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.ClickFilter("Men");
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.Assertions.ProductsAssertions.CheckIfProductIsInCategory("men");
        }
        [Test]
        public void P011_FindStore()
        {
            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu(); 
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.ViewFirstProductDetails();
            Context.ProductsPage.ClickStoreLocator();
            Context.Assertions.OurStoresPageWasOpened();           
        }
        [Test]
        public void P012_FavouritesInDeeplink()
        {
            Helpers.CloseCookiePolicy();
            Context.MobileMenu.ToggleMenu();
            Context.MobileMenu.OpenProducts();
            Context.MobileMenu.OpenProductCategory("undefined");    //new arrivals
            Context.ProductsPage.OpenFirstProductDeeplink();
            Context.ProductsPage.FavouriteProductInDeeplink();
            Context.Assertions.ProductsAssertions.FirstFavouriteWasAdded();
            Context.ProductsPage.ConfirmFirstFavourite();
            Context.Assertions.ProductsAssertions.DeeplinkFavouriteButtonIsBlue();
        }
    }
}
