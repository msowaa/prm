﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;


namespace Automation.TestsMobile
{
    //[TestFixture]
    class M001_SignInUp : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();

        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }


        [Test]
        public void P001_SignInEmail()
        {
            string email = "rafal.szypulewski@smtsoftware.com";
            string password = "qwerty32167";

            Helpers.SignIn(driver, email, password, false);
            Context.Assertions.SignInSignUpAssertions.UserWasSignedIn();
        }


        [Test]
        public void P002_SignInFacebook()
        {
            string email = "primarktest@gmail.com";
            string password = "qwerty32167";

            Helpers.SignIn(driver, email, password, true);
            Context.Assertions.SignInSignUpAssertions.UserWasSignedIn();

        }

        [Test]
        public void P003_SignInValidation()
        {
            string email = "qwerty";
            string password = "qwerty";

            Helpers.CloseCookiePolicy();
            Context.Header.SignIn();            
            Context.SignInSignUpPage.ClickSignIn();
            Context.Assertions.SignInSignUpAssertions.SignInValidationEmptyEmail();
            Context.Assertions.SignInSignUpAssertions.SignInValidationEmptyPassword();

            Context.SignInSignUpPage.FillEmailSignInFieldWith(email);
            Context.SignInSignUpPage.ClickSignIn();
            Context.Assertions.SignInSignUpAssertions.SignInValidationInvalidEmail();
            
            email = "qwerty@asd";
            Context.SignInSignUpPage.FillEmailSignInFieldWith(email, true);
            Context.SignInSignUpPage.ClickSignIn();
            Context.Assertions.SignInSignUpAssertions.SignInValidationInvalidEmail();

            email = "qwerty" + Helpers.GetSaltWithout_Char() + "@asd.com";
            Context.SignInSignUpPage.FillEmailSignInFieldWith(email, true);
            Context.SignInSignUpPage.FillPasswordSignInFieldWith(password);
            Context.SignInSignUpPage.ClickSignIn();
            Context.Assertions.SignInSignUpAssertions.UserWasNotSignedIn();
        }


        [Test]
        public void P004_SignUpEmail()
        {
            string password = "qwerty";
            string email = "seleniumtester002+" + DateTime.Now.ToString("yyyyMMddHHmmss") + "@gmail.com";

            Helpers.CloseCookiePolicy();
            Context.Header.SignUp();            
            Context.SignInSignUpPage.FillNameFieldWith("abc");
            Context.SignInSignUpPage.FillEmailSignUpFieldWith(email);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(email);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(password);
            Context.SignInSignUpPage.ClickSignUp();
            Helpers.ActivateAccount("seleniumtester002@gmail.com", "qwer!234");

            Helpers.SignIn(driver, email, password, false);
            Context.Assertions.SignInSignUpAssertions.UserWasSignedIn();

        }

        [Test]
        public void P005_SignUpValidation()
        {
            string firstValidation = " ";
            string secondValidation = "qwer";
            string thirdValidation = "qwer@ty";
            string email1 = "qwer@ty.com";
            string email2 = "asdf@gh.com";
            string password = "qwerty";

            Helpers.CloseCookiePolicy();
            Context.Header.SignUp();
            Context.SignInSignUpPage.FillNameFieldWith(firstValidation);
            Context.SignInSignUpPage.FillEmailSignUpFieldWith(firstValidation);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(firstValidation);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(firstValidation);
            Context.SignInSignUpPage.ClickSignUp();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationEmptyName();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationEmptyEmail();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationEmptyConfirmEmail();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationEmptyPassword();

            Context.SignInSignUpPage.FillNameFieldWith(secondValidation, true);
            Context.SignInSignUpPage.FillEmailSignUpFieldWith(secondValidation, true);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(secondValidation, true);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(secondValidation, true);
            Context.SignInSignUpPage.ClickSignUp();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationInvalidEmail();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationInvalidConfirmEmail();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationPasswordTooShort();

            Context.SignInSignUpPage.FillEmailSignUpFieldWith(thirdValidation, true);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(thirdValidation, true);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(password, true);
            Context.SignInSignUpPage.ClickSignUp();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationInvalidEmail();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationInvalidConfirmEmail();

            Context.SignInSignUpPage.FillEmailSignUpFieldWith(email1, true);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(email2, true);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(password, true);
            Context.SignInSignUpPage.ClickSignUp();
            Context.Assertions.SignInSignUpAssertions.SignUpValidationEmailsDontMatch();
        }

        [Test]
        public void P006_CheckActivateAccountMessage()
        {
            string password = "qwerty";
            //string email = Helpers.CreateUser(driver);
            string email = "seleniumtester002+" + DateTime.Now.ToString("yyyyMMddHHmmss") + "@gmail.com";

            Context.Header.SignUp();
            Context.SignInSignUpPage.FillNameFieldWith("abc");
            Context.SignInSignUpPage.FillEmailSignUpFieldWith(email);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(email);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(password);
            Context.SignInSignUpPage.ClickSignUp();
            driverExt.RefreshPage();
            Context.Assertions.SignInSignUpAssertions.ActivateAccountMessageIsPresent();
            Helpers.ActivateAccount("seleniumtester002@gmail.com", "qwer!234");
            Context.Assertions.SignInSignUpAssertions.ActivateAccountMessageIsNotPresent();
        }


    }
}
