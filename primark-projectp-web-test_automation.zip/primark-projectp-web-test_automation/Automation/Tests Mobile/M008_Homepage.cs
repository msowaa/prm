﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Windows.Forms;
using Automation.Context;

namespace Automation.TestsMobile
{
    [TestFixture]
    class M008_Homepage : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_TopCarouselNavigation()
        {
            Header.OpenHomepage();
            Homepage.ViewSecondTopCarouselItem();
            Homepage.ViewThirdTopCarouselItem();
            if (!WebdriverBaseClass.IsMobile)
            {
                Assertions.HomepageAssertions.NextArrowNotDisplayed();
            }
            Homepage.ViewFirstTopCarouselItem();
            if (!WebdriverBaseClass.IsMobile)
            {
                Assertions.HomepageAssertions.PreviousArrowNotDisplayed();
                Homepage.ClickNextTopCarouselItem();
                Homepage.ClickPreviousTopCarouselItem();
            }
            Homepage.ViewFirstTopCarouselItem(true);
            Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P002_OpenProductsCTA()
        {
            Header.OpenHomepage();
            Homepage.OpenFirstCTA2To2();
            Assertions.ProductsPageWasOpened();
        }
        [Test]
        public void P003_OpenSocialLinksFeature()
        {
            Header.OpenHomepage();
            Homepage.OpenSocialLinksFeature();
            Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P004_OpenSocialLinks()
        {
            Header.OpenHomepage();
            Homepage.OpenSocialLinksFB();
            Assertions.HeaderAssertions.SocialLinksFBWasOpened();
            Homepage.OpenSocialLinksTwitter();
            Assertions.HeaderAssertions.SocialLinksTwitterWasOpened();
            Homepage.OpenSocialLinksPinterest();
            Assertions.HeaderAssertions.SocialLinksPinterestWasOpened();
            Homepage.OpenSocialLinksInstagram();
            Assertions.HeaderAssertions.SocialLinksInstagramWasOpened();
            Homepage.OpenSocialLinksGooglePlus();
            Assertions.HeaderAssertions.SocialLinksGooglePlusWasOpened();
        }
        [Test]
        public void P005_OpenFeatureRowFirstFeature()
        {
            Header.OpenHomepage();
            Homepage.OpenFeatureRowFirstFeature();
            Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P006_PrimaniaCarousel()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.OpenHomepage();
            Homepage.PrimaniaCarouselClickNextArrow();
            Homepage.PrimaniaCarouselClickPreviousArrow();
            Homepage.PrimaniaCarouselOpenLook();
            Assertions.PrimaniaAssertions.LookWasOpened();
            Header.OpenHomepage();
            Homepage.PrimaniaCarouselUploadLook();
            Assertions.PrimaniaAssertions.LookUploadPageWasOpened();
            Header.OpenHomepage();
            Homepage.PrimaniaCarouselBrowsePrimania();
            Assertions.PrimaniaPageWasOpened();
        }
        [Test]
        public void P007_ProductsCarousel()
        {
            Header.OpenHomepage();
            Homepage.ProductsCarouselClickNextArrow();
            Homepage.ProductsCarouselClickPreviousArrow();
            Homepage.ProductsCarouselFavouriteItem();
            Assertions.ProductsAssertions.FirstFavouriteWasAdded();
            ProductsPage.ConfirmFirstFavourite();
            Homepage.ProductsCarouselOpenProductDetails();
            Assertions.ProductsAssertions.DeeplinkWasOpended();
        }
    }
}
