﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Reflection;
using Automation.Context;


namespace Automation.TestsMobile
{
    class M004_Primania_regression : WebdriverBaseClass
    {

        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_AddLook()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string path = "//storage//emulated//0//testdata//UploadTest.png";
            string itemName = Helpers.GetSalt();
            string itemPrice = "10";
            string description = "test desc " + Helpers.GetSalt();

            Helpers.SignIn(driver, email, password, false);

            string lookId = Helpers.AddLookToPrimania(driver, path, itemName, itemPrice, description);
            PrimaniaPage.OpenAddedLook();
            Assertions.PrimaniaAssertions.CheckIfLookPriceIs(itemPrice);
            Assertions.PrimaniaAssertions.CheckIfLookDescriptionIs(description);
        }

        [Test]
        public void P002_FilterLooks()
        {
            string style = "Casual";

            Helpers.CloseCookiePolicy();
            Header.OpenPrimania();
            PrimaniaPage.OpenFilters();
            PrimaniaPage.ChooseCasualFilter();
            PrimaniaPage.OpenFirstFilteredLook();
            Assertions.PrimaniaAssertions.CheckIfLookStyleIs(style);
            Header.OpenPrimania();
            PrimaniaPage.OpenFilters();
            PrimaniaPage.RemoveFilter();
            PrimaniaPage.SortByPopularity();
            PrimaniaPage.OpenFilters();
            PrimaniaPage.SortByDate();
        }


        [Test]
        public void P003_ReportLook()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;
            string report = "automated test " + Helpers.GetSalt();

            Helpers.SignIn(driver, email, password, false);
            Header.OpenPrimania();
            PrimaniaPage.OpenFirstLook();
            PrimaniaPage.ReportLook(report);
        }

        [Test]
        public void P004_LooksNavigation()
        {
            Helpers.CloseCookiePolicy();
            Header.OpenPrimania();
            PrimaniaPage.OpenFirstLook();
            string url1 = driverExt.GetUrl();
            PrimaniaPage.NextLook();
            string url2 = driverExt.GetUrl();
            Assertions.StringsAreNotEqual(url1, url2);
            PrimaniaPage.PreviousLook();
            url2 = driverExt.GetUrl();
            Assertions.StringsAreEqual(url1, url2);
            if (!WebdriverBaseClass.IsMobile)
            {
                PrimaniaPage.CloseLook();
                Assertions.PrimaniaAssertions.LookWasClosed();
            }
        }

        [Test]
        public void P005_GivePrimarks()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.OpenPrimania();
            PrimaniaPage.OpenFirstLook();
            PrimaniaPage.FindLookWithoutPrimarks();
            PrimaniaPage.GivePrimarks();
            Assertions.PrimaniaAssertions.PrimarksWereGiven();
            PrimaniaPage.RemovePrimarks();
            Assertions.PrimaniaAssertions.PrimarksWereRemoved();
        }
    }
}