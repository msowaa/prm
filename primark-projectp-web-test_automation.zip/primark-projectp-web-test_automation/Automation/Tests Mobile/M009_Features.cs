﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Windows.Forms;
using Automation.Context;

namespace Automation.TestsMobile
{
    [TestFixture]
    class M009_Features : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }

        [Test]
        public void P001_TopCarouselNavigation()
        {
            Header.OpenFeatures();
            FeaturesPage.ViewSecondTopCarouselItem();
            FeaturesPage.ViewThirdTopCarouselItem();
            if (!WebdriverBaseClass.IsMobile)
            {
                Assertions.FeaturesAssertions.NextArrowNotDisplayed();
            }
            FeaturesPage.ViewFirstTopCarouselItem();
            if (!WebdriverBaseClass.IsMobile)
            {
                Assertions.FeaturesAssertions.PreviousArrowNotDisplayed();
                FeaturesPage.ClickNextTopCarouselItem();
                FeaturesPage.ClickPreviousTopCarouselItem();
            }
            FeaturesPage.ViewFirstTopCarouselItem(true);
        }
        [Test]
        public void P002_OpenFeatureFourRowContainer()
        {
            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();
            Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P003_OpenFeatureTwoRowContainer()
        {
            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromTwoRowContainer();
            Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P004_OpenFeature3To1Container()
        {
            Header.OpenFeatures();
            FeaturesPage.OpenFeatureFrom3To1Container();
            Assertions.FeaturesAssertions.FeatureWasOpened();
        }
        [Test]
        public void P005_FilterFeatures()
        {
            string filterFeaturesCategory = "MEN";

            Header.OpenFeatures();
            FeaturesPage.SelectFilter(filterFeaturesCategory);
            FeaturesPage.OpenFirstFeatureFromTwoRowContainer();
            Assertions.FeaturesAssertions.FeatureIsInCategory(filterFeaturesCategory);
        }
        [Test]
        public void P006_FeatureDeeplinkNavigation()
        {
            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();
            FeaturesPage.NextFeature();
            FeaturesPage.PreviousFeature();
        }
        [Test]
        public void P007_FollowUnfollowEditor()
        {
            string email = Users.PrimarkUser001.Email;
            string password = Users.PrimarkUser001.Password;

            Helpers.SignIn(driver, email, password, false);
            Header.ViewProfile();
            Helpers.ClearFollowing();
            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();
            FeaturesPage.ClickFollowUnfollowEditorButton();
            Assertions.FeaturesAssertions.EditorIsFollowed();
            FeaturesPage.ClickFollowUnfollowEditorButton();
            Assertions.FeaturesAssertions.EditorIsUnfollowed();
        }
        [Test]
        public void P008_ShareFeatureOnFB()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnFB(driver, email, password, description);
        }
        [Test]
        public void P009_ShareFeatureOnTwitter()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnTwitter(driver, email, password, description);
        }
        [Test]
        public void P010_ShareFeatureOnPinterest()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;

            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnPinterest(driver, email, password);
        }
        [Test]
        public void P011_ShareFeatureOnTumblr()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnTumblr(driver, email, password, description);
        }
        [Test]
        public void P012_ShareFeatureOnGooglePlus()
        {
            string email = Users.SocialServicesUser002.Email;
            string password = Users.SocialServicesUser002.Password;
            string description = Helpers.GetSalt();

            Header.OpenFeatures();
            FeaturesPage.OpenFirstFeatureFromFourRowContainer();

            Helpers.ShareOnGPlus(email, password, description);
        }
        [Test]
        public void P013_LoadMore()
        {
            Header.OpenFeatures();
            FeaturesPage.SelectFilter("Women");
            FeaturesPage.LoadMore();
            Assertions.FeaturesAssertions.MoreWasLoaded();
        }

    }
}
