﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Threading;

namespace Automation.TestsMobile
{
    [TestFixture]
    class M000_TestSetup : WebdriverBaseClass
    {
        [TestFixtureSetUp]
        public void Setup()
        {
            base.SetUpTestMobile();
        }

        [SetUp]
        public void SetupTest()
        {
            base.SetUpTestMobile();
        }

        [TestFixtureTearDown]
        public void TearDown()
        {
            base.TeardownTest();
        }

        [TearDown]
        public void TestTearDown()
        {
            base.TeardownTest();
        }


        [Test]
        public void AddUsers()
        {
            string email1 = Users.PrimarkUser001.Email;
            string password1 = Users.PrimarkUser001.Password;

            string email2 = Users.PrimarkUser002.Email;
            string password2 = Users.PrimarkUser002.Password;

            string email3 = Users.PasswordChangeUser.Email;
            string password3 = Users.PasswordChangeUser.Password;

            CreateUser(email1, password1);
            CreateUser(email2, password2);
            CreateUser(email3, password3);
        }

        public void CreateUser(string email, string password)
        {
            Helpers.CloseCookiePolicy();
            Context.Header.SignUp();
            Context.SignInSignUpPage.FillNameFieldWith("abc");
            Context.SignInSignUpPage.FillEmailSignUpFieldWith(email);
            Context.SignInSignUpPage.FillConfirmEmailSignUpFieldWith(email);
            Context.SignInSignUpPage.FillPasswordSignUpFieldWith(password);
            Context.SignInSignUpPage.ClickSignUp();
            Helpers.ActivateAccount(email, "qwer!234");
        }

    }
}
